<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\LoginController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\ProfileController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\ServiceController;


Route::get('/', function () {
    return view('welcome');
});

Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login'])->name('admin.login.submit');
Route::post('/logout', [LoginController::class, 'logout'])->name('admin.logout');
Route::post('logout', [ProfileController::class, 'logout'])->name('admin.settings.logout');


Route::group(['middleware' => 'auth', 'namespace' => 'Admin', 'prefix' => 'admin'], function ($routes) {
    
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('admin.dashboard');

    Route::group(['prefix' => 'users'], function ($router) {
        Route::get('/',  [UserController::class, 'index'])->name('admin.user.index');
        Route::get('/create', [UserController::class, 'create'])->name('admin.user.create');
        Route::post('/store', [UserController::class, 'store'])->name('admin.user.store');
        Route::get('/view/{id}', [UserController::class, 'view'])->name('admin.user.view');
        Route::post('/update/{id}', [UserController::class, 'update'])->name('admin.user.update');
        Route::get('/edit/{id}',  [UserController::class, 'edit'])->name('admin.user.edit');
        Route::post('/destroy', [UserController::class, 'destroy'])->name('admin.user.destroy');
        Route::post('/status', [UserController::class, 'admin_users_status_update'])->name('admin.user.admin_users_status_update');
    });

    Route::group(['prefix' => 'categories'], function ($router) {
        Route::get('/',  [CategoryController::class, 'index'])->name('admin.category.index');
        Route::get('/create', [CategoryController::class, 'create'])->name('admin.category.create');
        Route::post('/store', [CategoryController::class, 'store'])->name('admin.category.store');
        Route::get('/view/{id}', [CategoryController::class, 'view'])->name('admin.category.view');
        Route::post('/update/{id}', [CategoryController::class, 'update'])->name('admin.category.update');
        Route::get('/edit/{id}',  [CategoryController::class, 'edit'])->name('admin.category.edit');
        Route::post('/destroy', [CategoryController::class, 'destroy'])->name('admin.category.destroy');
        Route::post('/status', [CategoryController::class, 'admin_users_status_update'])->name('admin.category.admin_users_status_update');
    });

    Route::group(['prefix' => 'products'], function ($router) {
        Route::get('/',  [ProductController::class, 'index'])->name('admin.product.index');
        Route::get('/create', [ProductController::class, 'create'])->name('admin.product.create');
        Route::post('/store', [ProductController::class, 'store'])->name('admin.product.store');
        Route::get('/view/{id}', [ProductController::class, 'view'])->name('admin.product.view');
        Route::post('/update/{id}', [ProductController::class, 'update'])->name('admin.product.update');
        Route::get('/edit/{id}',  [ProductController::class, 'edit'])->name('admin.product.edit');
        Route::post('/destroy', [ProductController::class, 'destroy'])->name('admin.product.destroy');
        Route::post('/status', [ProductController::class, 'admin_users_status_update'])->name('admin.product.admin_users_status_update');
    });

    Route::group(['prefix' => 'services'], function ($router) {
        Route::get('/',  [ServiceController::class, 'index'])->name('admin.service.index');
        Route::get('/create', [ServiceController::class, 'create'])->name('admin.service.create');
        Route::post('/store', [ServiceController::class, 'store'])->name('admin.service.store');
        Route::get('/view/{id}', [ServiceController::class, 'view'])->name('admin.service.view');
        Route::post('/update/{id}', [ServiceController::class, 'update'])->name('admin.service.update');
        Route::get('/edit/{id}',  [ServiceController::class, 'edit'])->name('admin.service.edit');
        Route::post('/destroy', [ServiceController::class, 'destroy'])->name('admin.service.destroy');
        Route::post('/status', [ServiceController::class, 'admin_users_status_update'])->name('admin.service.admin_users_status_update');
    });

    Route::group(['prefix' => 'settings'], function ($router) {
        Route::get('profile', [ProfileController::class, 'profile'])->name('admin.setting.profile');
        Route::post('/profile-update/{id}', [ProfileController::class, 'update'])->name('admin.setting.profile_update');
        Route::get('change-password', [ProfileController::class, 'changePasswordForm'])->name('admin.setting.changePasswordForm');
        Route::post('/change-password/{id}', [ProfileController::class, 'changePassword'])->name('admin.setting.changePassword');
    });
});