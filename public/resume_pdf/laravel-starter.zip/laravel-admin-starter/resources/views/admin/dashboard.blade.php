@extends('layouts.main')
@section('content')
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="content-wrapper">
            <div class="content-header row">
            </div>
            <div class="content-body">
                <section id="dashboard-ecommerce">
                        <div class="row">
                            <div class="col-xl-12 col-12 dashboard-users">
                                <div class="row ">
                                    <div class="col-12">
                                        <div class="row">
                                            <div class="col-sm-3 col-12 dashboard-users-success">
                                                <div class="card text-center">
                                                    <div class="card-body py-1">
                                                        <div class="badge-circle badge-circle-lg badge-circle-light-success mx-auto mb-50">
                                                            <i class="bx bx-briefcase-alt font-medium-5"></i>
                                                        </div>
                                                        <div class="text-muted line-ellipsis">Active Users</div>
                                                        <h3 class="mb-0">{{$activeUsersCount}}</h3>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-3 col-12 dashboard-users-danger">
                                                <div class="card text-center">
                                                    <div class="card-body py-1">
                                                        <div class="badge-circle badge-circle-lg badge-circle-light-danger mx-auto mb-50">
                                                            <i class="bx bx-user font-medium-5"></i>
                                                        </div>
                                                        <div class="text-muted line-ellipsis">Inactive Users</div>
                                                        <h3 class="mb-0">{{$inActiveUsersCount}}</h3>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-3 col-12 dashboard-users-danger">
                                                <div class="card text-center">
                                                    <div class="card-body py-1">
                                                        <div class="badge-circle badge-circle-lg badge-circle-light-success mx-auto mb-50">
                                                            <i class="bx bxs-zap text-primary font-size-base"></i>
                                                        </div>
                                                        <div class="text-muted line-ellipsis">Total Users </div>
                                                        <h3 class="mb-0">{{$contactCount}}</h3>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-3 col-12 dashboard-users-danger">
                                                <div class="card text-center">
                                                    <div class="card-body py-1">
                                                        <div class="badge-circle badge-circle-lg badge-circle-light-danger mx-auto mb-50">
                                                            <i class="bx bx-stats text-info font-size-base"></i>
                                                        </div>
                                                        <div class="text-muted line-ellipsis">Lorem Text</div>
                                                        <h3 class="mb-0">{{$customFieldCount}}</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-12 col-12 dashboard-order-summary">
                                <div class="card">
                                    <div class="row">
                                        <div class="col-md-12 col-12 order-summary">
                                            <div class="card mb-0">
                                                <div class="card-header d-flex justify-content-between align-items-center">
                                                    <h4 class="card-title">Contacts Summary</h4>
                                                    <div class="d-flex">
                                                        <button type="button" class="btn btn-sm btn-light-primary mr-1">Week</button>
                                                        <button type="button" class="btn btn-sm btn-primary glow">Month</button>
                                                    </div>
                                                </div>
                                                <div class="card-body p-0">
                                                    <div id="order-summary-chart"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </section>
            </div>
        </div>
    </div>
@endsection
@push('scripts')
@endpush