<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRM Enterprise | User & Service Management</title>
    
    <!-- Premium Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- FontAwesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/bootstrap.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/bootstrap-extended.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/assets/css/welcome.css') }}">
</head>
<body>

    <!-- Header Navigation -->
    <nav class="navbar navbar-expand-lg custom-navbar">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="fa-solid fa-cubes"></i> CRM Enterprise
            </a>
            <div class="ml-auto">
                <a href="{{ route('login') }}" class="btn btn-outline-premium btn-sm">
                    <i class="fa-solid fa-right-to-bracket mr-1"></i> Admin Login
                </a>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <!-- Text Area -->
                <div class="col-lg-6 col-12 mb-5 mb-lg-0">
                    <div class="tech-badge">
                        <i class="fa-solid fa-code-branch"></i> Laravel 13 & Frest Admin
                    </div>
                    <h1 class="hero-title">
                        Enterprise <span>User & Service</span> Management System
                    </h1>
                    <p class="hero-subtitle">
                        An elegant, high-performance Laravel workspace for managing customer relations, service offerings, catalog operations, and admin properties with full auditing and secure authorization.
                    </p>
                    <div class="d-flex flex-wrap gap-3" style="gap: 15px;">
                        <a href="{{ route('login') }}" class="btn-premium">
                            Enter Dashboard <i class="fa-solid fa-arrow-right"></i>
                        </a>
                    </div>
                </div>
                
                <!-- Graphic Illustration -->
                <div class="col-lg-6 col-12 illustration-container">
                    <div class="illustration-bg"></div>
                    <img src="{{ asset('build/theme/app-assets/image/maintenance-2.png') }}" class="illustration-img" alt="Under Maintenance Graphic">
                </div>
            </div>

            <!-- Features Summary -->
            <div class="row mt-5 pt-4">
                <!-- Feature 1 -->
                <div class="col-md-4 col-12 mb-4">
                    <div class="glass-card">
                        <div class="card-icon">
                            <i class="fa-solid fa-users-gear"></i>
                        </div>
                        <h3 class="h4 mb-2">User Directory</h3>
                        <p class="text-muted mb-0">Create, control, and update system users and staff accounts with real-time status management.</p>
                    </div>
                </div>

                <!-- Feature 2 -->
                <div class="col-md-4 col-12 mb-4">
                    <div class="glass-card">
                        <div class="card-icon">
                            <i class="fa-solid fa-briefcase"></i>
                        </div>
                        <h3 class="h4 mb-2">Service Catalog</h3>
                        <p class="text-muted mb-0">Manage services, categories, and inventory items with elegant Eloquent accessor-mutator casting.</p>
                    </div>
                </div>

                <!-- Feature 3 -->
                <div class="col-md-4 col-12 mb-4">
                    <div class="glass-card">
                        <div class="card-icon">
                            <i class="fa-solid fa-shield-halved"></i>
                        </div>
                        <h3 class="h4 mb-2">Toastr & Security</h3>
                        <p class="text-muted mb-0">Experience smooth, robust client-side validation, password rotations, and state-of-the-art notifications.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="custom-footer text-center">
        <div class="container">
            <p class="mb-0">&copy; {{ date('Y') }} CRM Enterprise. Engineered for excellence in Laravel.</p>
        </div>
    </footer>

    <!-- Bootstrap Core JS -->
    <script src="{{ asset('build/theme/app-assets/vendors/js/vendors.min.js') }}"></script>
</body>
</html>