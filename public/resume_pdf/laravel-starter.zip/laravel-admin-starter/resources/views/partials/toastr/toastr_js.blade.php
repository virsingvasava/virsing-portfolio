<script>
    toastr.options = {
        "closeButton": true,
        "progressBar": true,
        "positionClass": "custom-toast-position", 
        "timeOut": "7000",
    };
    if ($('#toastr-container').length) {
        toastr.options.target = '#toastr-container';
    }

    @if(session('toastr'))
        const toastrData = @json(session('toastr'));
        toastr[toastrData.type](toastrData.message);
    @endif
</script>
