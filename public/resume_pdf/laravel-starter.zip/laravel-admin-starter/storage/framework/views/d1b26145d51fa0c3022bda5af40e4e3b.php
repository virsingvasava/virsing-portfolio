   <style>
        #login-toastr-container .custom-toast-position {
            position: relative !important;
            top: 0 !important;
            left: 0 !important;
            right: 0 !important;
            bottom: 0 !important;
            width: 100% !important;
            max-width: 100% !important;
            margin: 0 0 15px 0 !important;
            padding: 0 !important;
            background: none !important;
            box-shadow: none !important;
            z-index: auto !important;
        }
        #login-toastr-container .custom-toast-position > div {
            margin: 0 !important;
            padding: 12px 15px 12px 45px !important;
            width: 100% !important;
            max-width: 100% !important;
            min-height: 40px !important;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05) !important;
            border-radius: 4px !important;
        }
    </style><?php /**PATH /var/www/html/laravel-practical-app/resources/views/partials/toastr/toastr_login_page.blade.php ENDPATH**/ ?>