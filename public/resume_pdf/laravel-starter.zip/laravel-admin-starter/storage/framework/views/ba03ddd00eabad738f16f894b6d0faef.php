<style>
    .custom-toast-position {
        top: 85px;  
        right: 30px; 
        position: fixed; 
        z-index: 99999;
    }
    
    #toastr-container {
        position: relative;
        min-width: 320px;
        min-height: 48px;
        display: flex;
        justify-content: flex-end;
        align-items: center;
        z-index: 9999;
    }
    
    #toastr-container .custom-toast-position {
        position: absolute !important;
        top: 0 !important;
        right: 0 !important;
        left: auto !important;
        bottom: auto !important;
        z-index: 9999;
        margin: 0;
        padding: 0;
        width: 100%;
        max-width: 320px;
    }
    
    @media (max-width: 575.98px) {
        #toastr-container {
            min-width: 100%;
            margin-top: 10px;
        }
        #toastr-container .custom-toast-position {
            position: relative !important;
            max-width: 100%;
        }
    }
</style><?php /**PATH /var/www/html/laravel-practical-app/resources/views/partials/toastr/toastr_css.blade.php ENDPATH**/ ?>