<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-12 mb-2 mt-1">
                    <div class="breadcrumbs-top">
                        <h5 class="content-header-title float-left pr-1 mb-0">Services</h5>
                        <div class="breadcrumb-wrapper d-none d-sm-block">
                            <ol class="breadcrumb p-0 mb-0 pl-1">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="bx bx-home-alt"></i></a>
                                </li>
                                <li class="breadcrumb-item active">Service
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content-body">
                <section id="basic-datatable">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body card-dashboard">
                                    <div class="d-flex flex-wrap justify-content-between align-items-center mb-1">
                                        <a class="btn btn-primary" href="<?php echo e(route('admin.service.create')); ?>">
                                            <i class="bx bx-plus"></i>&nbsp; Add New
                                        </a>
                                        <div id="toastr-container"></div>
                                    </div>
                                    <div class="table-responsive">
                                        <table id="table zero-configuration table-extended-chechbox" class="table zero-configuration">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Description</th>
                                                    <th>Slug</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $serviceArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                    <td><?php echo e($value->name); ?></td>
                                                    <td><?php echo e($value->description); ?></td>
                                                    <td><?php echo e($value->slug); ?></td>
                                                    <td>
                                                        <div class="dropdown">
                                                            <span class="bx bx-dots-vertical-rounded font-medium-3 dropdown-toggle nav-hide-arrow cursor-pointer" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" role="menu">
                                                            </span>
                                                            <div class="dropdown-menu dropdown-menu-right">
                                                                <a class="dropdown-item" href="<?php echo e(route('admin.service.view', $value->id)); ?>"><i class="bx bx-detail mr-1" data-icon="users"></i> View</a>
                                                                <a class="dropdown-item delete-btn" data-id="<?php echo e($value->id); ?>" href="javascript:void(0);"><i class="bx bx-trash mr-1"></i> delete</a>
                                                            </div>
                                                            <div class="d-inline-block">
                                                                <a href="<?php echo e(route('admin.service.edit', $value->id)); ?>" class="btn btn-sm btn-icon item-edit" style="margin-top: -10px; padding:0rem;"><i class="bx bxs-edit"></i></a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('commonJS/deleteItem.js')); ?>"></script>
<script>
    initializeDeleteAction('.delete-btn', '<?php echo e(route("admin.service.destroy")); ?>');
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/laravel-practical-app/resources/views/admin/services/index.blade.php ENDPATH**/ ?>