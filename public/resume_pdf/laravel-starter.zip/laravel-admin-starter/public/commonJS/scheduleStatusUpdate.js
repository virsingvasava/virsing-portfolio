
function initializeStatusUpdateAction(selector, ajaxUrl) {
    $(document).on('click', '.status-change', function () {
        let scheduleId = $(this).data('id');
        let newStatus = $(this).data('status');
        let badge = $(this).closest('td').find('.badge');
        let dropdown = $(this).closest('.dropdown-menu');
        
        const itemId = this.getAttribute('data-id');

        $.ajax({
            type: "POST",
            url: ajaxUrl,
            data: {
                _token: $('meta[name="csrf-token"]').attr('content'),
                id: scheduleId,
                status: newStatus
            },
            success: function (response) {
                if (response.success) {
                    let newStatusText = newStatus.charAt(0).toUpperCase() + newStatus.slice(1);
    
                    // ✅ Smooth fade + blink animation
                    badge.fadeOut(200, function () {
                        $(this)
                            .text(newStatusText)
                            .removeClass('badge-success badge-danger')
                            .addClass(newStatus === 'available' ? 'badge-success' : 'badge-danger')
                            .fadeIn(200)
                            .addClass('badge-blink'); // Blink effect
                    });
    
                    // ✅ Toggle dropdown option for reverse action
                    dropdown.html(`
                        <a class="dropdown-item status-change" href="javascript:void(0);" 
                            data-id="${scheduleId}" data-status="${newStatus === 'available' ? 'unavailable' : 'available'}">
                            <i class="bx ${newStatus === 'available' ? 'bx-x-circle' : 'bx-check-circle'} mr-1"></i> 
                            Mark as ${newStatus === 'available' ? 'Unavailable' : 'Available'}
                        </a>
                    `);
    
                    toastr.success('Status updated successfully!');
                } else {
                    toastr.error(response.message || 'Failed to update status!');
                }
            },
            error: function () {
                toastr.error('Something went wrong!');
            }
        });
    });
}
