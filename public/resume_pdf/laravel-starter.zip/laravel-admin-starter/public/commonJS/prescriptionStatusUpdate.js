
function initializeStatusUpdateAction(selector, ajaxUrl) {
    $(document).on('click', '.status-change', function () {
        let prescriptionId = $(this).data('id');
        let newStatus = $(this).data('status');
        let badge = $(this).closest('td').find('.badge');
        let dropdown = $(this).closest('.dropdown-menu');

        $.ajax({
            type: "POST",
            url: ajaxUrl,
            data: {
                _token: $('meta[name="csrf-token"]').attr('content'),
                id: prescriptionId,
                status: newStatus
            },
            success: function (response) {
                if (response.success) {
                    let newStatusText = newStatus.charAt(0).toUpperCase() + newStatus.slice(1);
    
                    badge
                        .text(newStatusText)
                        .removeClass('badge-success badge-warning badge-danger')
                        .addClass(
                            newStatus === 'active' ? 'badge-success' : 
                            newStatus === 'completed' ? 'badge-warning' : 'badge-danger'
                        );
    
                    dropdown.html(`
                        <a class="dropdown-item status-change" href="javascript:void(0);" 
                           data-id="${prescriptionId}" 
                           data-status="${newStatus === 'active' ? 'completed' : 'active'}">
                           <i class="bx ${newStatus === 'active' ? 'bx-check-circle' : 'bx-x-circle'}"></i>
                           Mark as ${newStatus === 'active' ? 'Completed' : 'Active'}
                        </a>
                    `);
    
                    toastr.success('Status updated successfully!');
                } else {
                    toastr.error('Failed to update status!');
                }
            },
            error: function () {
                toastr.error('Something went wrong!');
            }
        });
    });
    
}
