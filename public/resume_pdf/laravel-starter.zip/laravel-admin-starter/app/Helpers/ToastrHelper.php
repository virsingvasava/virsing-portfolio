<?php

namespace App\Helpers;

class ToastrHelper
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }

    public static function flash(string $type, string $message): void
    {
        session()->flash('toastr', [
            'type' => $type,
            'message' => $message,
        ]);
    }
}



