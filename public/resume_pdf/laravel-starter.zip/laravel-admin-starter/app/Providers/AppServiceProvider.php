<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Repositories\Contracts\UserRepositoryInterface;
use App\Repositories\UserRepository;

use App\Repositories\Contracts\ProfileRepositoryInterface;
use App\Repositories\ProfileRepository;

use App\Repositories\Contracts\CategoryRepositoryInterface;
use App\Repositories\CategoryRepository;

use App\Repositories\Contracts\ProductRepositoryInterface;
use App\Repositories\ProductRepository;

use App\Repositories\Contracts\ServiceRepositoryInterface;
use App\Repositories\ServiceRepository;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        $this->app->bind(UserRepositoryInterface::class, UserRepository::class);
        $this->app->bind(ProfileRepositoryInterface::class, ProfileRepository::class);
        $this->app->bind(CategoryRepositoryInterface::class, CategoryRepository::class);
        $this->app->bind(ProductRepositoryInterface::class, ProductRepository::class);
        $this->app->bind(ServiceRepositoryInterface::class, ServiceRepository::class);
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        //
    }
}
