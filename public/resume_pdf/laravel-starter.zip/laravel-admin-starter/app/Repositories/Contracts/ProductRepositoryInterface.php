<?php

namespace App\Repositories\Contracts;
use App\Models\Product;

interface ProductRepositoryInterface
{
    public function getAll();
    public function getById($id);
    public function create(array $data): Product;
    public function update($id, array $data): bool;
    public function delete($id): bool;
    public function count();
}