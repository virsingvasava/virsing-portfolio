<?php

namespace App\Repositories\Contracts;
use App\Models\Category;

interface CategoryRepositoryInterface
{
    public function getAll();
    public function getById($id);
    public function create(array $data): Category;
    public function update($id, array $data): bool;
    public function delete($id): bool;
    public function count();
}