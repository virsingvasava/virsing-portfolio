<?php

namespace App\Repositories;

use App\Repositories\Contracts\CategoryRepositoryInterface;
use App\Models\Category;

class CategoryRepository implements CategoryRepositoryInterface
{
    public function __construct(Category $model)
    {
        $this->model = $model;
    }

    public function getAll()
    {
        return  $this->model->all();
    }

    public function getById($id)
    {
        return  $this->model->findOrFail($id);
    }

    public function create(array $data): Category
    {
        return  $this->model->create($data);
    }

    public function update($id, array $data): bool
    {
        $category = $this->getById($id);
        return $category->update($data);
    }

    public function delete($id): bool
    {
        $category = $this->getById($id);
        return $category->delete();
    }

    public function count()
    {
        return $this->model->count();
    }
}
