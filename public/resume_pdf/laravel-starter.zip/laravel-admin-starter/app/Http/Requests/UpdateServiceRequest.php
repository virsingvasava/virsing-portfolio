<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class UpdateServiceRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $serviceId = $this->route('id');

        return [
            'name' => 'required|string|max:255|unique:services,name,' . $serviceId,
            'description' => 'nullable|string',
            'slug' => 'nullable|string|max:255',
            'status' => 'required|string|in:active,inactive',
        ];
    }
    
    protected function prepareForValidation()
    {
        $slug = $this->input('slug') ?: \Str::slug($this->input('name'));
        $originalSlug = $slug;
        $counter = 1;
        $serviceId = $this->route('id');

        while (\DB::table('services')->where('slug', $slug)->where('id', '!=', $serviceId)->exists()) {
            $slug = $originalSlug . '-' . $counter++;
        }

        $this->merge(['slug' => $slug]);
    }
}

