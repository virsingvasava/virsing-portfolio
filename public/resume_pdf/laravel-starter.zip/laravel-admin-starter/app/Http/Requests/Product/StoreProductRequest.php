<?php

namespace App\Http\Requests\Product;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Str;
use Illuminate\Support\DB;

class StoreProductRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => 'required|string|max:255|unique:products,name',
            'price' => 'required|numeric|min:0',
            'status' => 'nullable|string|max:255',
            'slug' => 'nullable|string|max:255',
        ];
    }

    protected function prepareForValidation()
    {
        $slug = $this->input('slug') ?: \Str::slug($this->input('name'));
        $originalSlug = $slug;
        $counter = 1;

        while (\DB::table('products')->where('slug', $slug)->exists()) {
            $slug = $originalSlug . '-' . $counter++;
        }

        $this->merge(['slug' => $slug]);
    }

}
