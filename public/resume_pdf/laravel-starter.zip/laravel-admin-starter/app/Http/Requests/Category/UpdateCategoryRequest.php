<?php

namespace App\Http\Requests\Category;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule; // 👈 Important
use Illuminate\Support\Str;
use Illuminate\Support\DB;

class UpdateCategoryRequest extends FormRequest
{
   
    public function rules(): array
    {
        $categoryId = $this->route('id');

        return [
            'name' => 'required|string|max:255|unique:categories,name,' . $categoryId,
            'status' => 'nullable|string|max:255',
            'slug' => 'nullable|string|max:255',
        ];
    }
    protected function prepareForValidation()
    {
        $slug = $this->input('slug') ?: \Str::slug($this->input('name'));
        $originalSlug = $slug;
        $counter = 1;

        while (\DB::table('categories')->where('slug', $slug)->exists()) {
            $slug = $originalSlug . '-' . $counter++;
        }

        $this->merge(['slug' => $slug]);
    }
}
