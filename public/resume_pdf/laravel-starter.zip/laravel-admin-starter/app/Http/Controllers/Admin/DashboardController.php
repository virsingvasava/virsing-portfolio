<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Helpers\ToastrHelper;

class DashboardController extends Controller
{
    public function index()
    {
        $users = User::all();

        $activeUsersCount = User::where('status', true)->count();
        $inActiveUsersCount = User::where('status', false)->count();

        $contactCount = User::count();
        $customFieldCount = User::count();

        return view('admin.dashboard', compact(
            'users',
            'activeUsersCount',
            'inActiveUsersCount',
            'contactCount',
            'customFieldCount'
        ));
    }
}
