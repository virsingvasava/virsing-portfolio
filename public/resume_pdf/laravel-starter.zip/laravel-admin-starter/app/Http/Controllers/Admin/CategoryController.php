<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Helpers\ToastrHelper;
use App\Repositories\Contracts\CategoryRepositoryInterface;
use App\Http\Requests\Category\StoreCategoryRequest;
use App\Http\Requests\Category\UpdateCategoryRequest;

class CategoryController extends Controller
{
    protected $categoryRepository;

    public function __construct(CategoryRepositoryInterface $categoryRepository)
    {
        $this->categoryRepository = $categoryRepository;
    }
    
    public function index(Request $request)
    {
        $categoryArray = $this->categoryRepository->getAll();
        return view('admin.categories.index', compact('categoryArray'));

    }

    public function create()
    {
        return view('admin.categories.create');
    }

    public function store(StoreCategoryRequest $request)
    {
        $this->categoryRepository->create($request->validated());
        ToastrHelper::flash('info', 'Category created successfully !');
        return redirect()->route('admin.category.index');
    }

    public function update($id, UpdateCategoryRequest $request)
    {
        $this->categoryRepository->update($id, $request->validated());
        ToastrHelper::flash('info', 'Category Updated successfully !');
        return redirect()->route('admin.category.index');
    }

    public function edit(Request $request, $id)
    {
        $category = $this->categoryRepository->getById($id);
        if (!$category) {
            ToastrHelper::flash('error', 'Category not found !');
            return redirect()->route('admin.category.index');
        }
        return view('admin.categories.edit', compact('category'));
    }

    public function view(Request $request, $id)
    {
        $category = $this->categoryRepository->getById($id);
        if (!$category) {
            ToastrHelper::flash('error', 'Category not found !');
            return redirect()->route('user.category.index');
        }
        return view('admin.categories.view', compact('category'));
    }

    public function destroy(Request $request)
    {
        $isDeleted = $this->categoryRepository->delete($request->id);
        return response()->json([
            'success' => $isDeleted,
            'message' => $isDeleted ? 'Item deleted successfully!' : 'Item not found or could not be deleted.',
        ], $isDeleted ? 200 : 404);
    }
}
