<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $guard = 'categories';

    protected $fillable = [
        'name',
        'slug',
        'status',
    ];
}
