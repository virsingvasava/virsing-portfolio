<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $guard = 'products';

    protected $fillable = [
        'name',
        'price',
        'status',
        'slug',
    ];
}
