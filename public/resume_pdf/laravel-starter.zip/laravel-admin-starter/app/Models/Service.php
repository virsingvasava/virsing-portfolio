<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Casts\Attribute;

class Service extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'description',
        'slug',
        'status',
    ];

    protected function status(): Attribute
    {
        return Attribute::make(
            get: fn (mixed $value) => $value ? 'active' : 'inactive',
            set: fn (mixed $value) => $value === 'active' || $value === 1 || $value === true ? 1 : 0,
        );
    }
}
