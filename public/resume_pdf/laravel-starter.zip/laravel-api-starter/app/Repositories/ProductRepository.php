<?php

namespace App\Repositories;

use App\Models\Product;
use App\Repositories\Interfaces\ProductRepositoryInterface;

class ProductRepository implements ProductRepositoryInterface
{
    public function getAll()
    {
        return Product::with('category')
            ->latest()
            ->paginate(10);
    }

    public function findById(int $id)
    {
        return Product::with('category')
            ->findOrFail($id);
    }

    public function store(array $data)
    {
        return Product::create($data);
    }

    public function update(int $id, array $data)
    {
        $product = $this->findById($id);

        $product->update($data);

        return $product;
    }

    public function delete(int $id)
    {
        $product = $this->findById($id);

        return $product->delete();
    }
}