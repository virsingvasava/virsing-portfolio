<?php

namespace App\Repositories\Interfaces;

interface CategoryRepositoryInterface
{
    public function getAll();

    public function findById(int $id);

    public function store(array $data);

    public function update(int $id, array $data);

    public function delete(int $id);
}