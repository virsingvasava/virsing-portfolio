<?php

namespace App\Http\Controllers\API;

use Illuminate\Support\Facades\Hash;
use App\Traits\ApiResponseTrait;
use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use App\Http\Requests\Auth\RegisterRequest;
use App\Repositories\Interfaces\UserRepositoryInterface;

class AuthController extends Controller
{
    use ApiResponseTrait;

    protected UserRepositoryInterface $userRepository;

    public function __construct(
        UserRepositoryInterface $userRepository
    ) {
        $this->userRepository = $userRepository;
    }

    /**
     * Register User
     */
    public function register(RegisterRequest $request)
    {
        try {

            $data = $request->validated();

            $data['password'] = bcrypt($data['password']);

            $user = $this->userRepository->create($data);

            $token = $user->createToken('auth_token')
                ->plainTextToken;

            return $this->successResponse(
                'User registered successfully.',
                [
                    'user' => $user,
                    'token' => $token,
                ],
                201
            );

        } catch (\Exception $e) {

            return $this->errorResponse(
                'Registration failed.',
                $e->getMessage(),
                500
            );
        }
    }

    /**
     * Login User
     */
    public function login(LoginRequest $request)
    {
        try {

            $user = $this->userRepository
                ->findByEmail($request->email);

            if (!$user || !Hash::check(
                $request->password,
                $user->password
            )) {

                return $this->errorResponse(
                    'Invalid credentials.',
                    [],
                    401
                );
            }

            $token = $user->createToken('auth_token')
                ->plainTextToken;

            return $this->successResponse(
                'Login successful.',
                [
                    'user' => $user,
                    'token' => $token,
                ]
            );

        } catch (\Exception $e) {

            return $this->errorResponse(
                'Login failed.',
                $e->getMessage(),
                500
            );
        }
    }

    /**
     * Logout User
     */
    public function logout()
    {
        try {

            auth()->user()
                ->currentAccessToken()
                ->delete();

            return $this->successResponse(
                'Logout successful.'
            );

        } catch (\Exception $e) {

            return $this->errorResponse(
                'Logout failed.',
                $e->getMessage(),
                500
            );
        }
    }

    /**
     * User Profile
     */
    public function profile()
    {
        return $this->successResponse(
            'Profile fetched successfully.',
            auth()->user()
        );
    }
}