<?php

namespace App\Http\Controllers\API;

use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Traits\ApiResponseTrait;
use App\Http\Controllers\Controller;
use App\Http\Requests\Product\StoreRequest;
use App\Http\Requests\Product\UpdateRequest;
use App\Repositories\Interfaces\ProductRepositoryInterface;

class ProductController extends Controller
{
    use ApiResponseTrait;

    protected ProductRepositoryInterface $productRepository;

    public function __construct(
        ProductRepositoryInterface $productRepository
    ) {
        $this->productRepository = $productRepository;
    }

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        try {

            $products = $this->productRepository->getAll();

            return $this->successResponse(
                'Product list fetched successfully.',
                $products
            );

        } catch (\Exception $e) {

            return $this->errorResponse(
                'Something went wrong.',
                $e->getMessage(),
                500
            );
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreRequest $request)
    {
        try {

            $data = $request->validated();

            $data['slug'] = Str::slug($data['name']);

            /*
            |--------------------------------------------------------------------------
            | Upload Image
            |--------------------------------------------------------------------------
            */

            if ($request->hasFile('image')) {

                $image = $request->file('image');

                $imageName = time() . '.' .
                    $image->getClientOriginalExtension();

                $image->storeAs(
                    'products',
                    $imageName,
                    'public'
                );

                $data['image'] = $imageName;
            }

            $product = $this->productRepository->store($data);

            return $this->successResponse(
                'Product created successfully.',
                $product,
                201
            );

        } catch (\Exception $e) {

            return $this->errorResponse(
                'Something went wrong.',
                $e->getMessage(),
                500
            );
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        try {

            $product = $this->productRepository->findById($id);

            return $this->successResponse(
                'Product details fetched successfully.',
                $product
            );

        } catch (\Exception $e) {

            return $this->errorResponse(
                'Product not found.',
                $e->getMessage(),
                404
            );
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateRequest $request, string $id)
    {
        try {

            $data = $request->validated();

            $data['slug'] = Str::slug($data['name']);

            /*
            |--------------------------------------------------------------------------
            | Upload Image
            |--------------------------------------------------------------------------
            */

            if ($request->hasFile('image')) {

                $image = $request->file('image');

                $imageName = time() . '.' .
                    $image->getClientOriginalExtension();

                $image->storeAs(
                    'products',
                    $imageName,
                    'public'
                );

                $data['image'] = $imageName;
            }

            $product = $this->productRepository
                ->update($id, $data);

            return $this->successResponse(
                'Product updated successfully.',
                $product
            );

        } catch (\Exception $e) {

            return $this->errorResponse(
                'Something went wrong.',
                $e->getMessage(),
                500
            );
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {

            $this->productRepository->delete($id);

            return $this->successResponse(
                'Product deleted successfully.'
            );

        } catch (\Exception $e) {

            return $this->errorResponse(
                'Something went wrong.',
                $e->getMessage(),
                500
            );
        }
    }
}