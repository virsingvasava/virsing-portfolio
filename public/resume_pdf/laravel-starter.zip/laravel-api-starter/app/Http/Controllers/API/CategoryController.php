<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\Category\StoreRequest;
use App\Http\Requests\Category\UpdateRequest;
use App\Repositories\Interfaces\CategoryRepositoryInterface;
use App\Traits\ApiResponseTrait;
use Illuminate\Support\Str;

class CategoryController extends Controller
{
    use ApiResponseTrait;

    protected CategoryRepositoryInterface $categoryRepository;

    public function __construct(
        CategoryRepositoryInterface $categoryRepository
    ) {
        $this->categoryRepository = $categoryRepository;
    }

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        try {

            $categories = $this->categoryRepository->getAll();

            return $this->successResponse(
                'Category list fetched successfully.',
                $categories
            );

        } catch (\Exception $e) {

            return $this->errorResponse(
                'Something went wrong.',
                500,
                $e->getMessage()
            );
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreRequest $request)
    {
        try {

            $data = $request->validated();

            $data['slug'] = Str::slug($data['name']);

            $category = $this->categoryRepository->store($data);

            return $this->successResponse(
                'Category created successfully.',
                $category,
                201
            );

        } catch (\Exception $e) {

            return $this->errorResponse(
                'Something went wrong.',
                500,
                $e->getMessage()
            );
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(int $id)
    {
        try {

            $category = $this->categoryRepository->findById($id);

            return $this->successResponse(
                'Category details fetched successfully.',
                $category
            );

        } catch (\Exception $e) {

            return $this->errorResponse(
                'Category not found.',
                404,
                $e->getMessage()
            );
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateRequest $request, int $id)
    {
        try {

            $data = $request->validated();

            $data['slug'] = Str::slug($data['name']);

            $category = $this->categoryRepository->update($id, $data);

            return $this->successResponse(
                'Category updated successfully.',
                $category
            );

        } catch (\Exception $e) {

            return $this->errorResponse(
                'Something went wrong.',
                500,
                $e->getMessage()
            );
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(int $id)
    {
        try {

            $this->categoryRepository->delete($id);

            return $this->successResponse(
                'Category deleted successfully.'
            );

        } catch (\Exception $e) {

            return $this->errorResponse(
                'Something went wrong.',
                500,
                $e->getMessage()
            );
        }
    }
}