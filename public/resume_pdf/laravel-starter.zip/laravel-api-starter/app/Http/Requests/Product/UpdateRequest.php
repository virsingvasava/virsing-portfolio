<?php

namespace App\Http\Requests\Product;

use Illuminate\Foundation\Http\FormRequest;

class UpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Validation rules.
     */
    public function rules(): array
    {
        $productId = $this->route('product');

        return [
            'category_id' => 'required|exists:categories,id',

            'name' => 'required|string|max:255|unique:products,name,' . $productId,

            'description' => 'nullable|string',

            'price' => 'required|numeric|min:1',

            'stock' => 'required|integer|min:0',

            'image' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',

            'status' => 'required|in:active,inactive',
        ];
    }
}