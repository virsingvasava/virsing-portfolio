<?php

namespace App\Helpers;

class ApiResponse
{
    public static function success(
        string $message,
        mixed $data = [],
        int $code = 200
    ) {
        return response()->json([
            'success' => true,
            'message' => $message,
            'data' => $data,
        ], $code);
    }

    public static function error(
        string $message,
        mixed $errors = [],
        int $code = 400
    ) {
        return response()->json([
            'success' => false,
            'message' => $message,
            'errors' => $errors,
        ], $code);
    }
}