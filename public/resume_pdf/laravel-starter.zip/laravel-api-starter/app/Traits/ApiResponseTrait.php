<?php

namespace App\Traits;

trait ApiResponseTrait
{
    public function successResponse(
        string $message,
        mixed $data = [],
        int $code = 200
    ) {
        return response()->json([
            'success' => true,
            'message' => $message,
            'data' => $data,
        ], $code);
    }

    public function errorResponse(
        string $message,
        mixed $errors = [],
        int $code = 400
    ) {
        return response()->json([
            'success' => false,
            'message' => $message,
            'errors' => $errors,
        ], $code);
    }
}