<?php

    $user = null;
    if (auth('admin')->check()) {
        $user = auth('admin')->user(); 
    } elseif (auth('employee')->check()) {
        $user = auth('employee')->user(); 
    } elseif (auth('user')->check()) {
        $user = auth('user')->user();
    }
    $adminUser = App\Models\User::where('id', $user->user_id)->first();

?>

<a class="dropdown-toggle nav-link dropdown-user-link" href="javascript:void(0);" data-toggle="dropdown">
    <div class="user-nav d-sm-flex d-none">
        <?php if($adminUser && $adminUser->first_name && $adminUser->last_name): ?>
            <span class="user-name">
                <?php echo e($adminUser->first_name); ?> <?php echo e($adminUser->last_name); ?>

            </span>
        <?php elseif($user && $user->first_name && $user->last_name): ?>
            <span class="user-name">
                <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>

            </span>
        <?php else: ?>
            <span class="user-name">Lorem Text</span>
        <?php endif; ?>
    </div>
    <span>
        
        <?php if($adminUser && $adminUser->profile_picture && $adminUser->profile_picture): ?>
            <img class="rounded-circle" src="<?php echo e(asset($adminUser->profile_picture)); ?>" alt="Profile Picture" height="40" width="40">
        <?php elseif($user && $user->profile_picture): ?>
            <img class="rounded-circle" src="<?php echo e(asset($user->profile_picture)); ?>" alt="Profile Picture" height="40" width="40">
        <?php else: ?>
            <img class="rounded-circle" src="<?php echo e(asset('build/theme/app-assets/image/avatar-s-70.png')); ?>" alt="Default Avatar" height="40" width="40">
        <?php endif; ?>
    </span>
</a>
<?php /**PATH /var/www/html/laravel-practical-starter/resources/views/partials/sub_header/name_profile.blade.php ENDPATH**/ ?>