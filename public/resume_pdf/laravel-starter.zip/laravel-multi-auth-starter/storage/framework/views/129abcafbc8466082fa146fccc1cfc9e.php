
<li class="nav-item is-shown <?php echo e(request()->is('admin/users*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('admin.user.index')); ?>"><i class="menu-icon tf-icons bx bx-detail"
    data-icon="users"></i><span class="menu-title text-truncate" data-i18n="Menu">Users</span>
    </a>
</li>

<li class="nav-item is-shown <?php echo e(request()->is('admin/user-block-unblock*') ? 'active' : ''); ?>">
    <a href="<?php echo e(route('admin.block_unblock.index')); ?>"><i class="menu-icon tf-icons bx bx-detail"
    data-icon="users"></i><span class="menu-title text-truncate" data-i18n="Menu">Block Unblock</span>
    </a>
</li>

<?php /**PATH /var/www/html/laravel-practical-starter/resources/views/partials/admin.blade.php ENDPATH**/ ?>