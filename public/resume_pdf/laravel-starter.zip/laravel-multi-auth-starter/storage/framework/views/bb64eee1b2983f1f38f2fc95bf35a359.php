<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>AccessCRM - Enterprise Portal</title>
    
    <!-- Premium Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/welcome.css')); ?>">
</head>
<body>

    <!-- Ambient Wave-like Backgrounds -->
    <div class="wave-bg">
        <div class="wave wave-1"></div>
        <div class="wave wave-2"></div>
        <div class="wave wave-3"></div>
    </div>

    <!-- Navigation Header -->
    <header>
        <div class="logo-container">
            <div class="logo-icon">
                <!-- Lock Icon SVG -->
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                    <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                </svg>
            </div>
            <span class="logo-text">AccessCRM</span>
        </div>
        <div class="status-badge">
            <span class="status-dot"></span>
            System Operational
        </div>
    </header>

    <!-- Main Container -->
    <main>
        
        <!-- Hero Header -->
        <section class="hero">
            <span class="hero-badge">v2.4 LTS • Secure Access Node</span>
            <h1>Enterprise CRM Gateway</h1>
            <p>Select your assigned operational portal to manage inventory catalogs, toggle fine-grained RBAC policies, and audit system activities securely.</p>
        </section>

        <!-- Role Portal Grid -->
        <section class="portal-grid">
            
            <!-- Admin Portal Card -->
            <div class="portal-card card-admin">
                <div class="icon-wrapper">
                    <!-- Security Shield SVG with Pop violet/blue color -->
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                        <defs>
                            <linearGradient id="grad-admin" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" stop-color="#8487f9" />
                                <stop offset="100%" stop-color="#5a8dee" />
                            </linearGradient>
                        </defs>
                        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" stroke="url(#grad-admin)" />
                        <path d="M12 8v4" stroke="url(#grad-admin)" />
                        <path d="M12 16h.01" stroke="url(#grad-admin)" />
                    </svg>
                </div>
                <h2>Administrator</h2>
                <p>Full system control. Toggle user active/blocked states, monitor resource usage, audit access logs, and manage comprehensive RBAC privileges.</p>
                <a href="<?php echo e(route('admin.login')); ?>" class="portal-btn btn-admin">
                    Launch Admin Console
                    <span class="btn-arrow">→</span>
                </a>
            </div>

            <!-- User Portal Card -->
            <div class="portal-card card-user">
                <div class="icon-wrapper">
                    <!-- Database SVG with Pop teal/cyan color -->
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                        <defs>
                            <linearGradient id="grad-user" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" stop-color="#00cfdd" />
                                <stop offset="100%" stop-color="#00b6c2" />
                            </linearGradient>
                        </defs>
                        <ellipse cx="12" cy="5" rx="9" ry="3" stroke="url(#grad-user)" />
                        <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" stroke="url(#grad-user)" />
                        <path d="M3 12c0 1.66 4 3 9 3s9-1.34 9-3" stroke="url(#grad-user)" />
                    </svg>
                </div>
                <h2>CRM User</h2>
                <p>Operations workspace. Add and update catalog products, manage database category hierarchies, and review operational statistics dashboards.</p>
                <a href="<?php echo e(route('user.login')); ?>" class="portal-btn btn-user">
                    Enter User Workspace
                    <span class="btn-arrow">→</span>
                </a>
            </div>

            <!-- Employee Portal Card -->
            <div class="portal-card card-employee">
                <div class="icon-wrapper">
                    <!-- Briefcase SVG with Pop orange/amber color -->
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                        <defs>
                            <linearGradient id="grad-employee" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" stop-color="#fdac41" />
                                <stop offset="100%" stop-color="#e59b36" />
                            </linearGradient>
                        </defs>
                        <rect x="2" y="7" width="20" height="14" rx="2" ry="2" stroke="url(#grad-employee)" />
                        <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" stroke="url(#grad-employee)" />
                    </svg>
                </div>
                <h2>Employee</h2>
                <p>Support panel. Review active categories, search live inventory lists, manage assigned workspace tasks, and update basic profiling fields.</p>
                <a href="<?php echo e(route('employee.login')); ?>" class="portal-btn btn-employee">
                    Access Employee Panel
                    <span class="btn-arrow">→</span>
                </a>
            </div>

        </section>

        <!-- System Capabilities Section -->
        <section style="display: none;" class="features-section">
            <h2>Secure Enterprise Architecture</h2>
            <div class="features-grid">
                
                <!-- Multi-Guard Isolation -->
                <div class="feature-card">
                    <span class="feature-badge badge-purple">Multi-Guard Isolation</span>
                    <h3>Isolated Auth Contexts</h3>
                    <p>Leverages dedicated Laravel session guards completely separating database schemas and middleware check scopes between tiers.</p>
                </div>

                <!-- Dynamic RBAC Controls -->
                <div class="feature-card">
                    <span class="feature-badge badge-cyan">Security Management</span>
                    <h3>Dynamic Access Blocking</h3>
                    <p>System Administrators hold structural rights to toggle active states, triggering immediate logout and session invalidation.</p>
                </div>

                <!-- Lightweight Design -->
                <div class="feature-card">
                    <span class="feature-badge badge-teal">Performance Core</span>
                    <h3>High-Speed UX Engine</h3>
                    <p>Designed with zero heavy JavaScript frameworks. Standardized self-contained, light footprint layout loads in milliseconds.</p>
                </div>

            </div>
        </section>

    </main>

    <!-- Footer -->
    <footer>
        <p>&copy; 2026 AccessCRM Security Node. Multi-guard isolated environments. All access routes are monitored and logged.</p>
    </footer>

</body>
</html><?php /**PATH /var/www/html/laravel-practical-starter/resources/views/welcome.blade.php ENDPATH**/ ?>