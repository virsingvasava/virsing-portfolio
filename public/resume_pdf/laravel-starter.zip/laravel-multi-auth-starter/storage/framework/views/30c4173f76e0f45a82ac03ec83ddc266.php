<script>
    <?php if(session('toastr')): ?>
        toastr.options = {
            "closeButton": true,
            "progressBar": true,
            "positionClass": "custom-toast-position", 
            "timeOut": "7000",
        };
        const toastrData = <?php echo json_encode(session('toastr'), 15, 512) ?>;
        toastr[toastrData.type](toastrData.message);
    <?php endif; ?>
</script>
<?php /**PATH /var/www/html/laravel-practical-starter/resources/views/partials/toastr/toastr_js.blade.php ENDPATH**/ ?>