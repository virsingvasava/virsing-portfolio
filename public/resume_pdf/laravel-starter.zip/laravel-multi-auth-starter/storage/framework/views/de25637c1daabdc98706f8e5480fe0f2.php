<?php
    $guard = auth('admin')->check() ? 'admin' : (auth('employee')->check() ? 'employee' : (auth('user')->check() ? 'user' : null));
?>

<?php if($guard): ?>
    <a class="dropdown-item" href="<?php echo e(route($guard . '.setting.profile')); ?>">
        <i class="bx bx-user mr-50"></i> Edit Profile
    </a>
<?php endif; ?>
<?php /**PATH /var/www/html/laravel-practical-starter/resources/views/partials/sub_header/edit_profile.blade.php ENDPATH**/ ?>