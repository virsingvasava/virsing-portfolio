<?php
    $guard = null;

    if (Auth::guard('admin')->check()) {
        $guard = 'admin';
    } elseif (Auth::guard('user')->check()) {
        $guard = 'user';
    } elseif (Auth::guard('employee')->check()) {
        $guard = 'employee';
    }
?>

<?php if($guard): ?>
    <a class="dropdown-item" href="<?php echo e(route($guard . '.logout')); ?>"
       onclick="event.preventDefault(); document.getElementById('logout-form-<?php echo e($guard); ?>').submit();">
        <i class="bx bx-power-off mr-50"></i> Logout
    </a>

    <form id="logout-form-<?php echo e($guard); ?>" action="<?php echo e(route($guard . '.logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
    </form>
<?php endif; ?>
<?php /**PATH /var/www/html/laravel-practical-starter/resources/views/partials/sub_header/logout.blade.php ENDPATH**/ ?>