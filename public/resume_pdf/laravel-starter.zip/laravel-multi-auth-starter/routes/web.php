<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Admin\{
    DashboardController,
    ProfileController,
    AuthController,
    UserController,
    SettingController,
    AccountSettingController,
    UserBlockUnblockController,
};

use App\Http\Controllers\User\{
    LoginController, 
    DashboardController as UserDashboardController,
    AccountSettingController as UserAccountSettingController,
    CategoryController as UserCategoryController,
    ProductController as UserProductController,
};

use App\Http\Controllers\Employee\{
    LoginController as EmployeeLoginController,
    DashboardController as EmployeeDashboardController,
    AccountSettingController as EmployeeAccountSettingController,
    CategoryController as EmployeeCategoryController,
    ProductController as EmployeeProductController,
};

Route::get('/', function () {
    return view('welcome');
});

Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login'])->name('login.submit');
Route::post('/logout', [LoginController::class, 'logout'])->name('logout.submit');


// =====================
// Admin Routes
// =====================
Route::prefix('admin')->group(function () {
    Route::get('/login', [AuthController::class, 'adminLoginForm'])->name('admin.login');
    Route::post('/login', [AuthController::class, 'login'])->name('admin.login.submit');
    Route::post('/logout', [AuthController::class, 'logout'])->name('admin.logout');

    Route::middleware('auth:admin')->group(function () {
        Route::get('/dashboard', [DashboardController::class, 'index'])->name('admin.dashboard');

        Route::prefix('settings')->group(function () {
            Route::get('profile', [AccountSettingController::class, 'profile'])->name('admin.setting.profile');
            Route::post('/profile-update/{id}', [AccountSettingController::class, 'update'])->name('admin.setting.profile_update');
            Route::get('change-password', [AccountSettingController::class, 'changePasswordForm'])->name('admin.setting.changePasswordForm');
            Route::post('/change-password/{id}', [AccountSettingController::class, 'changePassword'])->name('admin.setting.changePassword');
        });

        Route::group(['prefix' => 'users'], function ($router) {
            Route::get('/',  [UserController::class, 'index'])->name('admin.user.index');
            Route::get('/create', [UserController::class, 'create'])->name('admin.user.create');
            Route::post('/store', [UserController::class, 'store'])->name('admin.user.store');
            Route::get('/view/{id}', [UserController::class, 'view'])->name('admin.user.view');
            Route::post('/update/{id}', [UserController::class, 'update'])->name('admin.user.update');
            Route::get('/edit/{id}',  [UserController::class, 'edit'])->name('admin.user.edit');
            Route::post('/destroy', [UserController::class, 'destroy'])->name('admin.user.destroy');
            Route::post('/status', [UserController::class, 'admin_users_status_update'])->name('admin.user.admin_users_status_update');
            
        });

        Route::group(['prefix' => 'user-block-unblock'], function ($router) {
            Route::get('/',  [UserBlockUnblockController::class, 'index'])->name('admin.block_unblock.index');
            Route::post('/block-unblock', [UserBlockUnblockController::class, 'user_block_unblock'])->name('admin.block_unblock.user_block_unblock');
        });
    });
});

// =====================
// User Routes
// =====================
Route::prefix('user')->group(function () {
    
    Route::get('/', [LoginController::class, 'index'])->name('user.welcome');
    Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
    Route::get('/login', [LoginController::class, 'showLoginForm'])->name('user.login');
    Route::post('/login', [LoginController::class, 'login'])->name('user.login.submit');
    Route::post('/logout', [LoginController::class, 'logout'])->name('user.logout');

    Route::get('/register', [LoginController::class, 'showRegisterForm'])->name('user.register');
    Route::post('/register', [LoginController::class, 'registerUsers'])->name('user.register.submit');

    Route::get('/activate/{token}', [LoginController::class, 'activate'])->name('user.activate');

    Route::middleware('auth:user')->group(function () {
        Route::get('/dashboard', [UserDashboardController::class, 'index'])->name('user.dashboard');

        Route::prefix('settings')->group(function () {
            Route::get('profile', [UserAccountSettingController::class, 'profile'])->name('user.setting.profile');
            Route::post('/profile-update/{id}', [UserAccountSettingController::class, 'update'])->name('user.setting.profile_update');
            Route::get('change-password', [UserAccountSettingController::class, 'changePasswordForm'])->name('user.setting.changePasswordForm');
            Route::post('/change-password/{id}', [UserAccountSettingController::class, 'changePassword'])->name('user.setting.changePassword');
        });

        Route::group(['prefix' => 'categories'], function ($router) {
            Route::get('/',  [UserCategoryController::class, 'index'])->name('user.category.index');
            Route::get('/create', [UserCategoryController::class, 'create'])->name('user.category.create');
            Route::post('/store', [UserCategoryController::class, 'store'])->name('user.category.store');
            Route::get('/view/{id}', [UserCategoryController::class, 'view'])->name('user.category.view');
            Route::post('/update/{id}', [UserCategoryController::class, 'update'])->name('user.category.update');
            Route::get('/edit/{id}',  [UserCategoryController::class, 'edit'])->name('user.category.edit');
            Route::post('/destroy', [UserCategoryController::class, 'destroy'])->name('user.category.destroy');
            Route::post('/status', [UserCategoryController::class, 'admin_users_status_update'])->name('user.category.admin_users_status_update');
        });

        Route::group(['prefix' => 'products'], function ($router) {
            Route::get('/',  [UserProductController::class, 'index'])->name('user.product.index');
            Route::get('/create', [UserProductController::class, 'create'])->name('user.product.create');
            Route::post('/store', [UserProductController::class, 'store'])->name('user.product.store');
            Route::get('/view/{id}', [UserProductController::class, 'view'])->name('user.product.view');
            Route::post('/update/{id}', [UserProductController::class, 'update'])->name('user.product.update');
            Route::get('/edit/{id}',  [UserProductController::class, 'edit'])->name('user.product.edit');
            Route::post('/destroy', [UserProductController::class, 'destroy'])->name('user.product.destroy');
            Route::post('/status', [UserProductController::class, 'admin_users_status_update'])->name('user.product.admin_users_status_update');
        });
    });
});


// =====================
// Employee Routes
// =====================
Route::prefix('employee')->group(function () {
    // Route::get('/login', [EmployeeLoginController::class, 'showLoginForm'])->name('login');
    Route::get('/login', [EmployeeLoginController::class, 'showLoginForm'])->name('employee.login');
    Route::post('/login', [EmployeeLoginController::class, 'login'])->name('employee.login.submit');
    Route::post('/logout', [EmployeeLoginController::class, 'logout'])->name('employee.logout');

    Route::middleware('auth:employee')->group(function () {

        Route::get('/dashboard', [EmployeeDashboardController::class, 'index'])->name('employee.dashboard');

        Route::group(['prefix' => 'settings'], function ($router) {
            Route::get('profile', [EmployeeAccountSettingController::class, 'profile'])->name('employee.setting.profile');
            Route::post('/profile-update/{id}', [EmployeeAccountSettingController::class, 'update'])->name('employee.setting.profile_update');
            Route::get('change-password', [EmployeeAccountSettingController::class, 'changePasswordForm'])->name('employee.setting.changePasswordForm');
            Route::post('/change-password/{id}', [EmployeeAccountSettingController::class, 'changePassword'])->name('employee.setting.changePassword');
        });

        Route::group(['prefix' => 'categories'], function ($router) {
            Route::get('/',  [EmployeeCategoryController::class, 'index'])->name('employee.category.index');
            Route::get('/create', [EmployeeCategoryController::class, 'create'])->name('employee.category.create');
            Route::post('/store', [EmployeeCategoryController::class, 'store'])->name('employee.category.store');
            Route::get('/view/{id}', [EmployeeCategoryController::class, 'view'])->name('employee.category.view');
            Route::post('/update/{id}', [EmployeeCategoryController::class, 'update'])->name('employee.category.update');
            Route::get('/edit/{id}',  [EmployeeCategoryController::class, 'edit'])->name('employee.category.edit');
            Route::post('/destroy', [EmployeeCategoryController::class, 'destroy'])->name('employee.category.destroy');
        });

        Route::group(['prefix' => 'products'], function ($router) {
            Route::get('/',  [EmployeeProductController::class, 'index'])->name('employee.product.index');
            Route::get('/create', [EmployeeProductController::class, 'create'])->name('employee.product.create');
            Route::post('/store', [EmployeeProductController::class, 'store'])->name('employee.product.store');
            Route::get('/view/{id}', [EmployeeProductController::class, 'view'])->name('employee.product.view');
            Route::post('/update/{id}', [EmployeeProductController::class, 'update'])->name('employee.product.update');
            Route::get('/edit/{id}',  [EmployeeProductController::class, 'edit'])->name('employee.product.edit');
            Route::post('/destroy', [EmployeeProductController::class, 'destroy'])->name('employee.product.destroy');
        });

    });
});
