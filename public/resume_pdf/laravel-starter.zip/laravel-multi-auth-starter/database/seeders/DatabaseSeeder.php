<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Admin;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $admin = User::updateOrCreate([
            'name' => 'Super Admin',
            'first_name' => 'Super',
            'last_name' => 'Admin',
            'username' => 'superadmin', 
            'email' => 'admin@gmail.com',
            'phone_number' => '9999988888', 
            'profile_picture' => NULL, 
            'status' => 'active',
            'slug' => Str::slug('Super Admin'),
            'password' => Hash::make('password'), 
            'remember_token' => Str::random(10),
            'email_verified_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        
        Admin::create([
            'user_id' => $admin->id,
            'name' => 'Super Admin',
            'first_name' => 'Super',
            'last_name' => 'Admin',
            'username' => 'superadmin', 
            'email' => 'admin@gmail.com',
            'phone_number' => '9999988888', 
            'profile_picture' => NULL, 
            'status' => 'active',
            'slug' => Str::slug('Super Admin'),
            'password' => Hash::make('password'), 
            'remember_token' => Str::random(10),
            'email_verified_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        User::updateOrCreate([
            'name' => 'User',
            'first_name' => 'Panel',
            'last_name' => 'UserTest',
            'username' => 'UserTest3155', 
            'email' => 'user@gmail.com',
            'phone_number' => '9999988899', 
            'profile_picture' => NULL, 
            'status' => 'active',
            'slug' => Str::slug('User'),
            'password' => Hash::make('password'), 
            'remember_token' => Str::random(10),
            'email_verified_at' => now(),
            'user_type' => 'user',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $this->call([
            EmployeeSeeder::class,
        ]);
    }
}