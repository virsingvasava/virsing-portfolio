<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Employee;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class EmployeeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Single employee data
        $employee = [
            'first_name' => 'Lorem',
            'last_name' => 'Text',
            'email' => 'employee@gmail.com',
        ];

        // Create user entry
        $user = User::create([
            'name' => $employee['first_name'] . ' ' . $employee['last_name'],
            'first_name' => $employee['first_name'],
            'last_name' => $employee['last_name'],
            'username' => Str::lower($employee['first_name'] . '.' . $employee['last_name']),
            'email' => $employee['email'],
            'phone_number' => '9999999999',
            'profile_picture' => null,
            'status' => 'active',
            'slug' => Str::slug($employee['first_name'] . ' ' . $employee['last_name']),
            'password' => Hash::make('password'), 
            'user_type' => 'employee',
            'email_verified_at' => now(),
            'remember_token' => Str::random(10),
        ]);

        // Create Employee entry
        Employee::create([
            'user_id' => $user->id,
            'email' => $employee['email'],
            'password' => Hash::make('password'),
            'phone_number' => '9999999999',
            'email_verified_at' => now(),
            'remember_token' => Str::random(10),
        ]);
    }
}
