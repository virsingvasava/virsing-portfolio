<li class="nav-item is-shown {{ request()->is('employee/categories*') ? 'active' : '' }}">
    <a href="{{route('employee.category.index')}}"><i class="menu-icon tf-icons bx bx-detail"
    data-icon="users"></i><span class="menu-title text-truncate" data-i18n="Menu">Categories</span>
    </a>
</li>

<li class="nav-item is-shown {{ request()->is('employee/products*') ? 'active' : '' }}">
    <a href="{{route('employee.product.index')}}"><i class="menu-icon tf-icons bx bx-detail"
    data-icon="users"></i><span class="menu-title text-truncate" data-i18n="Menu">Products</span>
    </a>
</li>