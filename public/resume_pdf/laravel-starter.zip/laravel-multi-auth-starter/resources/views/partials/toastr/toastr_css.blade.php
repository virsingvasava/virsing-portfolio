<style>
    .custom-toast-position {
        top: 150px;  
        left: 950px; 
        right: auto;  
        bottom: auto;
        position: fixed; 
    }
</style>