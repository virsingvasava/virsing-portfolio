<script>
    @if(session('toastr'))
        toastr.options = {
            "closeButton": true,
            "progressBar": true,
            "positionClass": "custom-toast-position", 
            "timeOut": "7000",
        };
        const toastrData = @json(session('toastr'));
        toastr[toastrData.type](toastrData.message);
    @endif
</script>
