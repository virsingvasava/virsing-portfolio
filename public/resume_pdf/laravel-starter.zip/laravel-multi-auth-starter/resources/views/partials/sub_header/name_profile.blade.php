@php

    $user = null;
    if (auth('admin')->check()) {
        $user = auth('admin')->user(); 
    } elseif (auth('employee')->check()) {
        $user = auth('employee')->user(); 
    } elseif (auth('user')->check()) {
        $user = auth('user')->user();
    }
    $adminUser = App\Models\User::where('id', $user->user_id)->first();

@endphp

<a class="dropdown-toggle nav-link dropdown-user-link" href="javascript:void(0);" data-toggle="dropdown">
    <div class="user-nav d-sm-flex d-none">
        @if($adminUser && $adminUser->first_name && $adminUser->last_name)
            <span class="user-name">
                {{ $adminUser->first_name }} {{ $adminUser->last_name }}
            </span>
        @elseif($user && $user->first_name && $user->last_name)
            <span class="user-name">
                {{ $user->first_name }} {{ $user->last_name }}
            </span>
        @else
            <span class="user-name">Lorem Text</span>
        @endif
    </div>
    <span>
        
        @if($adminUser && $adminUser->profile_picture && $adminUser->profile_picture)
            <img class="rounded-circle" src="{{ asset($adminUser->profile_picture) }}" alt="Profile Picture" height="40" width="40">
        @elseif($user && $user->profile_picture)
            <img class="rounded-circle" src="{{ asset($user->profile_picture) }}" alt="Profile Picture" height="40" width="40">
        @else
            <img class="rounded-circle" src="{{ asset('build/theme/app-assets/image/avatar-s-70.png') }}" alt="Default Avatar" height="40" width="40">
        @endif
    </span>
</a>
