@php
    $guard = auth('admin')->check() ? 'admin' : (auth('employee')->check() ? 'employee' : (auth('user')->check() ? 'user' : null));
@endphp

@if($guard)
    <a class="dropdown-item" href="{{ route($guard . '.setting.profile') }}">
        <i class="bx bx-user mr-50"></i> Edit Profile
    </a>
@endif
