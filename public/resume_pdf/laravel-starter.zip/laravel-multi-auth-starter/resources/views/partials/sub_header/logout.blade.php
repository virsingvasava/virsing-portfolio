@php
    $guard = null;

    if (Auth::guard('admin')->check()) {
        $guard = 'admin';
    } elseif (Auth::guard('user')->check()) {
        $guard = 'user';
    } elseif (Auth::guard('employee')->check()) {
        $guard = 'employee';
    }
@endphp

@if($guard)
    <a class="dropdown-item" href="{{ route($guard . '.logout') }}"
       onclick="event.preventDefault(); document.getElementById('logout-form-{{ $guard }}').submit();">
        <i class="bx bx-power-off mr-50"></i> Logout
    </a>

    <form id="logout-form-{{ $guard }}" action="{{ route($guard . '.logout') }}" method="POST" style="display: none;">
        @csrf
    </form>
@endif
