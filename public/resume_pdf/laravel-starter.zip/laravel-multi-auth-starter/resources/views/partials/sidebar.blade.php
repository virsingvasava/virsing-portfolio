@php
    $guard = auth('admin')->check() ? 'admin' : (auth('employee')->check() ? 'employee' : 'user');
@endphp

<!-- BEGIN: Main Menu -->
<div class="main-menu menu-fixed menu-dark menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">
            <li class="nav-item mr-auto">
                <a class="navbar-brand" href="{{ route($guard . '.dashboard') }}">
                    @php
                        $panelName = ucfirst($guard) . ' Panel';
                        if ($guard === 'employee') {
                            $panelName = 'Emp Panel';
                        }
                    @endphp
                    <h2 class="brand-text mb-0">{{ $panelName }} </h2>
                </a>
            </li>
            <li class="nav-item nav-toggle">
                <a class="nav-link modern-nav-toggle pr-0" data-toggle="collapse">
                    <i class="bx bx-x d-block d-xl-none font-medium-4 primary"></i>
                    <i class="toggle-icon bx bx-disc font-medium-4 d-none d-xl-block primary" data-ticon="bx-disc"></i>
                </a>
            </li>
        </ul>
    </div>

    <div class="shadow-bottom"></div>

    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation" data-icon-style="lines">
            <!-- Dashboard -->
            <li class="nav-item {{ request()->is($guard . '/dashboard') ? 'active' : '' }}">
                <a href="{{ route($guard . '.dashboard') }}">
                    <i class="menu-icon tf-icons bx bx-home-circle"></i>
                    <span class="menu-title text-truncate">Dashboard</span>
                </a>
            </li>

            <!-- Guard-specific menu -->

            @switch($guard)
                @case('admin')
                    @include('partials.admin')
                    @break

                @case('employee')
                    @include('partials.employee')
                    @break

                @case('user')
                    @include('partials.user')
                    @break
            @endswitch

            <!-- Common Settings Menu -->
            <li class="navigation-header text-truncate"><span>Profile & Settings</span></li>

            <li class="nav-item open {{ request()->is($guard.'/settings*') ? 'active' : '' }}">
                <a href="{{ route($guard.'.setting.profile') }}">
                    <i class="menu-icon tf-icons bx bx-dock-top" data-icon="settings"></i>
                    <span class="menu-title text-truncate">Account Settings</span>
                </a>
                <ul class="menu-content">
                    <li class="{{ request()->is($guard.'/settings/profile') ? 'active' : '' }}">
                        <a href="{{ route($guard.'.setting.profile') }}">
                            <i class="bx bx-right-arrow-alt"></i>
                            <span class="menu-item text-truncate">Profile</span>
                        </a>
                    </li>
                    <li class="{{ request()->is($guard.'/settings/change-password') ? 'active' : '' }}">
                        <a class="d-flex align-items-center" href="{{ route($guard.'.setting.changePasswordForm') }}">
                            <i class="bx bx-right-arrow-alt"></i>
                            <span class="menu-item text-truncate">Change Password</span>
                        </a>
                    </li>
                    <li class="{{ request()->is($guard.'/settings/logout') ? 'active' : '' }}">
                        <a href="{{ route($guard.'.logout') }}" 
                           onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <i class="bx bx-right-arrow-alt"></i>
                            <span class="menu-item text-truncate">Logout</span>
                        </a>
                        <form id="logout-form" action="{{ route($guard.'.logout') }}" method="POST" style="display: none;">
                            @csrf
                        </form>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</div>
<!-- END: Main Menu -->
