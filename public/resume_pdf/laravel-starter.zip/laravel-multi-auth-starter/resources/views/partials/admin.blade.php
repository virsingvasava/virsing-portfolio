
<li class="nav-item is-shown {{ request()->is('admin/users*') ? 'active' : '' }}">
    <a href="{{route('admin.user.index')}}"><i class="menu-icon tf-icons bx bx-detail"
    data-icon="users"></i><span class="menu-title text-truncate" data-i18n="Menu">Users</span>
    </a>
</li>

<li class="nav-item is-shown {{ request()->is('admin/user-block-unblock*') ? 'active' : '' }}">
    <a href="{{route('admin.block_unblock.index')}}"><i class="menu-icon tf-icons bx bx-detail"
    data-icon="users"></i><span class="menu-title text-truncate" data-i18n="Menu">Block Unblock</span>
    </a>
</li>

