<li class="nav-item is-shown {{ request()->is('user/categories*') ? 'active' : '' }}">
    <a href="{{route('user.category.index')}}"><i class="menu-icon tf-icons bx bx-detail"
    data-icon="users"></i><span class="menu-title text-truncate" data-i18n="Menu">Categories</span>
    </a>
</li>

<li class="nav-item is-shown {{ request()->is('user/products*') ? 'active' : '' }}">
    <a href="{{route('user.product.index')}}"><i class="menu-icon tf-icons bx bx-detail"
    data-icon="users"></i><span class="menu-title text-truncate" data-i18n="Menu">Products</span>
    </a>
</li>