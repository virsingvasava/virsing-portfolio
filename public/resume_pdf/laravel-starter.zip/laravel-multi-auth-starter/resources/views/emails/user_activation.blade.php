<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Activation</title>
</head>
<body style="font-family: Arial, sans-serif; background-color: #f4f6f8; margin: 0; padding: 20px;">

    <div class="container" style="background-color: #ffffff; max-width: 600px; margin: 30px auto; padding: 30px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);">
        <h2 style="font-size: 24px; color: #333333;">Welcome, {{ $first_name }} {{ $last_name }}!</h2>

        <p style="font-size: 16px; color: #333333;">Thank you for registering with us. Please activate your account by clicking the button below:</p>

        <a href="{{ $activation_link }}" style="display: inline-block; margin-top: 20px; padding: 12px 24px; background-color: #4CAF50; color: #ffffff; text-decoration: none; font-weight: bold; border-radius: 5px;">Activate My Account</a>

        <div class="credentials" style="margin-top: 20px; background: #f9f9f9; padding: 15px; border-radius: 5px; font-size: 14px; color: #333333;">
            <p style="margin: 5px 0; font-weight: bold;">Login Credentials:</p>
            <p style="margin: 5px 0;"><strong>Email:</strong> {{ $email }}</p>
            <p style="margin: 5px 0;"><strong>Phone number:</strong> {{ $phone_number }}</p>
        </div>

        <p style="font-size: 16px; color: #333333;">If you did not sign up for an account, you can safely ignore this email.</p>

        <div class="footer" style="margin-top: 30px; font-size: 12px; color: #777777; text-align: center;">
            &copy; {{ date('Y') }} Your User Management System (UMS). All rights reserved.
        </div>
    </div>

</body>
</html>
