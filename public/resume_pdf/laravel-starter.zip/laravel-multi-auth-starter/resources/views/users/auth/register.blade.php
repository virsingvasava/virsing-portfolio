<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="description"
        content="Frest admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities.">
    <meta name="keywords"
        content="admin template, Frest admin template, dashboard template, flat admin template, responsive admin template, web app">
    <meta name="author" content="PIXINVENT">
    <title>Register - UMS</title>
    <link rel="apple-touch-icon" href="{{ asset('build/theme/app-assets/images/ico/apple-icon-120.png') }}">
    <link rel="shortcut icon" type="image/x-icon" href="{{ asset('build/theme/app-assets/images/ico/favicon.ico') }}">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,600%7CIBM+Plex+Sans:300,400,500,600,700" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/vendors/css/vendors.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/vendors/css/extensions/toastr.css')}}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/bootstrap.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/bootstrap-extended.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/colors.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/components.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/themes/dark-layout.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/themes/semi-dark-layout.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/core/menu/menu-types/vertical-menu.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/pages/authentication.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/plugins/extensions/toastr.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/assets/css/style.css') }}">
    <style>
        .custom-toast-position {
            top:20px;  
            left: 900px; 
            right: auto;  
            bottom: auto;
            position: fixed; 
        }
    </style>
</head>
<body
    class="vertical-layout vertical-menu-modern semi-dark-layout 1-column  navbar-sticky footer-static bg-full-screen-image  blank-page"
    data-open="click" data-menu="vertical-menu-modern" data-col="1-column" data-layout="semi-dark-layout">
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="content-wrapper">
            <div class="content-header row">
            </div>
            <div class="content-body">
                <section class="row flexbox-container">
                    <div class="col-xl-8 col-10">
                        <div class="card bg-authentication mb-0">
                            <div class="row m-0">
                                <div class="col-md-6 col-12 px-0">
                                    <div
                                        class="card disable-rounded-right mb-0 p-2 h-100 d-flex justify-content-center">
                                        <div class="card-header pb-1" style="display:block">
                                            <div class="card-title">
                                                <h4 class="text-center mb-2">Sign Up</h4>
                                            </div>
                                        </div>
                                        <div class="text-center">
                                            <p> <small> Please enter your details to sign up and be part of our great
                                                    community</small>
                                            </p>
                                        </div>
                                        <div class="card-body">
                                            <form action="{{ route('user.register.submit') }}" class="form form-vertical" method="post" enctype="multipart/form-data">
                                                 @csrf
                                                <div class="form-row">
                                                    <div class="form-group col-md-6 mb-50">
                                                        <label for="first_name">First Name</label>
                                                        <input type="text" id="first_name" class="form-control @error('first_name') is-invalid @enderror" name="first_name" placeholder="First Name">
                                                        @error('first_name')
                                                        <div class="invalid-feedback">{{ $message }}</div>
                                                        @enderror
                                                    </div>
                                                    <div class="form-group col-md-6 mb-50">
                                                        <label for="last_name">Last Name</label>
                                                        <input type="text" id="last_name" class="form-control @error('last_name') is-invalid @enderror" name="last_name" placeholder="Last Name">
                                                        @error('last_name')
                                                        <div class="invalid-feedback">{{ $message }}</div>
                                                        @enderror
                                                    </div>
                                                </div>
                                                <div class="form-group mb-50">
                                                    <label for="email">Email</label>
                                                    <input type="email" id="email" class="form-control @error('email') is-invalid @enderror" name="email" placeholder="Email">
                                                    @error('email')
                                                    <div class="invalid-feedback">{{ $message }}</div>
                                                    @enderror
                                                </div>

                                                <!-- Phone Number -->
                                                <div class="form-group mb-50">
                                                    <label for="phone_number">Phone Number</label>
                                                    <input type="text" id="phone_number"
                                                        class="form-control @error('phone_number') is-invalid @enderror"
                                                        name="phone_number" placeholder="Phone Number">
                                                    @error('phone_number')
                                                        <div class="invalid-feedback">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                                <!-- Password -->
                                                <div class="form-group">
                                                    <label for="password">Password</label>
                                                    <input type="password" id="password"
                                                        class="form-control @error('password') is-invalid @enderror"
                                                        name="password" placeholder="Password">
                                                    @error('password')
                                                        <div class="invalid-feedback">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                                <div class="form-group">
                                                    <label for="password_confirmation">Confirm Password</label>
                                                    <input type="password" id="password_confirmation"
                                                        class="form-control @error('password_confirmation') is-invalid @enderror"
                                                        name="password_confirmation" placeholder="Confirm Password">
                                                    @error('password_confirmation')
                                                        <div class="invalid-feedback">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                                <!-- User Type -->
                                                <div class="form-group">
                                                    <label for="user_type">User Type</label>
                                                    <select id="user_type" name="user_type" class="form-control @error('user_type') is-invalid @enderror">
                                                        <option value="">Select User Type</option>
                                                        @foreach(\App\Enums\UserType::cases() as $userType)
                                                            <option value="{{ $userType->value }}" {{ old('user_type') == $userType->value ? 'selected' : '' }}>
                                                                {{ ucfirst($userType->value) }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                    @error('user_type')
                                                        <div class="invalid-feedback">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                                
                                                <!-- Profile Picture -->
                                                <div class="form-group">
                                                    <label for="profile_picture">Profile Picture</label>
                                                    <input type="file" id="profile_picture"
                                                        class="form-control @error('profile_picture') is-invalid @enderror"
                                                        name="profile_picture">
                                                    @error('profile_picture')
                                                        <div class="invalid-feedback">{{ $message }}</div>
                                                    @enderror
                                                </div>

                                                <button type="submit"
                                                    class="btn btn-primary glow position-relative w-100">SIGN UP<i
                                                        id="icon-arrow" class="bx bx-right-arrow-alt"></i></button>
                                            </form>
                                            <hr>
                                            <div class="text-center"><small class="mr-25">Already have an
                                                    account?</small><a href="{{ route('user.login') }}"><small>Sign in</small>
                                                </a></div>
                                        </div>
                                    </div>
                                </div>
                                <!-- image section right -->
                                <div class="col-md-6 d-md-block d-none text-center align-self-center p-3">
                                    <img class="img-fluid"
                                        src="{{ asset('build/theme/app-assets/image/register.png') }}" alt="branding logo">
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
    <script src="{{ asset('build/theme/app-assets/vendors/js/vendors.min.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/fonts/LivIconsEvo/js/LivIconsEvo.tools.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/fonts/LivIconsEvo/js/LivIconsEvo.defaults.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/fonts/LivIconsEvo/js/LivIconsEvo.min.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/js/scripts/configs/vertical-menu-dark.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/js/core/app-menu.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/js/core/app.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/js/scripts/components.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/js/scripts/footer.js') }}"></script>
    
    @include('partials.toastr.toastr_js')
</body>
</html>
