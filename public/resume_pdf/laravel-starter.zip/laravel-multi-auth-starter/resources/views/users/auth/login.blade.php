<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="description"
        content="Frest admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities.">
    <meta name="keywords"
        content="admin template, Frest admin template, dashboard template, flat admin template, responsive admin template, web app">
    <meta name="author" content="PIXINVENT">
    <title>Login - CRM</title>
    <link rel="apple-touch-icon" href="{{ asset('build/theme/app-assets/images/ico/apple-icon-120.png') }}">
    <link rel="shortcut icon" type="image/x-icon" href="{{ asset('build/theme/app-assets/images/ico/favicon.ico') }}">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,600%7CIBM+Plex+Sans:300,400,500,600,700"
        rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/vendors/css/vendors.min.css') }}">

    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/vendors/css/extensions/toastr.css')}}">

    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/bootstrap.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/bootstrap-extended.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/colors.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/components.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/themes/dark-layout.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/themes/semi-dark-layout.css') }}">

    <link rel="stylesheet" type="text/css"
        href="{{ asset('build/theme/app-assets/css/core/menu/menu-types/vertical-menu.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/pages/authentication.css') }}">

    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/plugins/extensions/toastr.css') }}">

    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/assets/css/style.css') }}">
    @include('partials.toastr.toastr_login_page')
</head>

<body
    class="vertical-layout vertical-menu-modern semi-dark-layout 1-column  navbar-sticky footer-static bg-full-screen-image  blank-page"
    data-open="click" data-menu="vertical-menu-modern" data-col="1-column" data-layout="semi-dark-layout">
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="content-wrapper">
            <div class="content-header row">
            </div>
            <div class="content-body">
                <section id="auth-login" class="row flexbox-container">
                    <div class="col-xl-8 col-11">
                        <div class="card bg-authentication mb-0">
                            <div class="row m-0">
                                <div class="col-md-6 col-12 px-0">
                                    <div class="card disable-rounded-right mb-0 p-2 h-100 d-flex justify-content-center">
                                        <div id="login-toastr-container"></div>
                                        <div class="card-header pb-1">
                                            <div class="card-title">
                                                <h4 class="text-center mb-2">Sign In to UMS User Panel</h4>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <form action="{{ route('user.login.submit') }}" method="POST" novalidate>
                                                @csrf
                                                <div class="form-group">
                                                    <label for="email">Email Address</label>
                                                    <input type="email" name="email"
                                                        class="form-control @error('email') is-invalid @enderror"
                                                        id="email" placeholder="Enter your email">
                                                    @error('email')
                                                        <div class="invalid-feedback">{{ $message }}</div>
                                                    @enderror
                                                </div>

                                                <div class="form-group">
                                                    <label for="password">Password</label>
                                                    <input type="password" name="password"
                                                        class="form-control @error('password') is-invalid @enderror"
                                                        id="password" placeholder="Enter your password">
                                                    @error('password')
                                                        <div class="invalid-feedback">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                                <button type="submit" class="btn btn-primary w-100">Login</button>
                                            </form>
                                            <hr>
                                            <div class="text-center"><small class="mr-25">Don't have an account?</small><a href="{{ route('user.register') }}"><small>Sign up</small></a></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 d-md-block d-none text-center align-self-center p-3">
                                    <img class="img-fluid" src="{{ asset('build/theme/app-assets/image/login.png') }}"
                                        alt="branding logo">
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>

    <script src="{{ asset('build/theme/app-assets/vendors/js/vendors.min.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/fonts/LivIconsEvo/js/LivIconsEvo.tools.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/fonts/LivIconsEvo/js/LivIconsEvo.defaults.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/fonts/LivIconsEvo/js/LivIconsEvo.min.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/vendors/js/extensions/toastr.min.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/js/scripts/configs/vertical-menu-dark.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/js/core/app-menu.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/js/core/app.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/js/scripts/components.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/js/scripts/footer.js') }}"></script>
    
    @if(session('toastr'))
    <script>
        toastr.options = {
            "closeButton": true,
            "progressBar": true,
            "positionClass": "custom-toast-position", 
            "timeOut": "7000",
            "target": "#login-toastr-container"
        };
        const toastrData = @json(session('toastr'));
        toastr[toastrData.type](toastrData.message);
    </script>
    @endif

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.querySelector('form');
            const emailInput = document.getElementById('email');
            const passwordInput = document.getElementById('password');

            function showError(input, message) {
                const group = input.closest('.form-group');
                let feedback = group.querySelector('.invalid-feedback');
                if (!feedback) {
                    feedback = document.createElement('div');
                    feedback.className = 'invalid-feedback';
                    group.appendChild(feedback);
                }
                feedback.textContent = message;
                input.classList.add('is-invalid');
            }

            function clearError(input) {
                const group = input.closest('.form-group');
                const feedback = group.querySelector('.invalid-feedback');
                if (feedback) {
                    feedback.remove();
                }
                input.classList.remove('is-invalid');
            }

            function validateEmail(email) {
                const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                return re.test(String(email).toLowerCase());
            }

            emailInput.addEventListener('input', function() {
                const val = this.value.trim();
                if (!val) {
                    showError(this, 'Email Address is required.');
                } else if (!validateEmail(val)) {
                    showError(this, 'Please enter a valid email address.');
                } else {
                    clearError(this);
                }
            });

            passwordInput.addEventListener('input', function() {
                const val = this.value;
                if (!val) {
                    showError(this, 'Password is required.');
                } else if (val.length < 6) {
                    showError(this, 'Password must be at least 6 characters long.');
                } else {
                    clearError(this);
                }
            });

            form.addEventListener('submit', function(e) {
                let isValid = true;

                const emailVal = emailInput.value.trim();
                if (!emailVal) {
                    showError(emailInput, 'Email Address is required.');
                    isValid = false;
                } else if (!validateEmail(emailVal)) {
                    showError(emailInput, 'Please enter a valid email address.');
                    isValid = false;
                }

                const passwordVal = passwordInput.value;
                if (!passwordVal) {
                    showError(passwordInput, 'Password is required.');
                    isValid = false;
                } else if (passwordVal.length < 6) {
                    showError(passwordInput, 'Password must be at least 6 characters long.');
                    isValid = false;
                }

                if (!isValid) {
                    e.preventDefault();
                }
            });
        });
    </script>
</body>
</html>
