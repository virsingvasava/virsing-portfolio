<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="description" content="Frest admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities.">
    <meta name="keywords" content="admin template, Frest admin template, dashboard template, flat admin template, responsive admin template, web app">
    <meta name="author" content="PIXINVENT">
    <title>Welcome CRM</title>
    <link rel="apple-touch-icon" href="{{ asset('build/theme/app-assets/images/ico/apple-icon-120.png')}}">
    <link rel="shortcut icon" type="image/x-icon" href="{{ asset('build/theme/app-assets/images/ico/favicon.ico')}}">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,600%7CIBM+Plex+Sans:300,400,500,600,700" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/vendors/css/vendors.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/bootstrap.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/bootstrap-extended.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/colors.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/components.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/themes/dark-layout.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/themes/semi-dark-layout.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/app-assets/css/core/menu/menu-types/vertical-menu.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('build/theme/assets/css/style.css') }}">
</head>
<body class="vertical-layout vertical-menu-modern semi-dark-layout 1-column  navbar-sticky footer-static bg-full-screen-image  blank-page" data-open="click" data-menu="vertical-menu-modern" data-col="1-column" data-layout="semi-dark-layout">
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="content-wrapper">
            <div class="content-header row">
            </div>
            <div class="content-body">
                <section class="row flexbox-container">
                    <div class="col-xl-7 col-md-8 col-12">
                        <div class="card bg-transparent shadow-none">
                            <div class="card-body text-center bg-transparent">
                                <img src="{{ asset('build/theme/app-assets/image/maintenance-2.png') }}" class="img-fluid" alt="under maintenance" width="200">
                                <h1 class="error-title my-1">User Management and Role-Based Access Control System for CRM !</h1>
                                <a href="{{ route('admin.login') }}" class="btn btn-primary round glow mt-2">Admin</a> 
                                <a href="{{ route('user.login') }}" class="btn btn-primary round glow mt-2">User</a>
                                <a href="{{ route('employee.login') }}" class="btn btn-primary round glow mt-2">Employee</a>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
    <script src="{{ asset('build/theme/app-assets/vendors/js/vendors.min.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/fonts/LivIconsEvo/js/LivIconsEvo.tools.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/fonts/LivIconsEvo/js/LivIconsEvo.defaults.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/fonts/LivIconsEvo/js/LivIconsEvo.min.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/js/scripts/configs/vertical-menu-dark.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/js/core/app-menu.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/js/core/app.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/js/scripts/components.js') }}"></script>
    <script src="{{ asset('build/theme/app-assets/js/scripts/footer.js') }}"></script>
</body>
</html>