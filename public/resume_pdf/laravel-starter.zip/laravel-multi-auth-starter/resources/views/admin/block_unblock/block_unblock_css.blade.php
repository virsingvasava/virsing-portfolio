<style>
.switch-clean {
    position: relative;
    display: inline-block;
    width: 106px;
    height: 40px;
}

.switch-clean input {
    opacity: 0;
    width: 0;
    height: 0;
}

.slider-clean {
    position: absolute;
    cursor: pointer;
    top: 0; 
    left: 0;
    right: 0; 
    bottom: 0;
    background-color: #dc3545; /* Block color */
    transition: .4s;
    border-radius: 34px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    font-weight: bold;
    color: white;
    padding: 0 10px;
    overflow: hidden;
}

.slider-clean:before {
    position: absolute;
    content: "";
    height: 32px;
    width: 32px;
    background-color: white;
    border-radius: 50%;
    bottom: 4px;
    left: 8px;
    transition: .4s;
}

.label-on, .label-off {
    width: 100%;
    text-align: center;
    opacity: 0;
    transition: opacity 0.4s;
    position: absolute;
    
}
.label-on {
    font-size: 12px;
    margin-right: 35px;
    margin-top: 5px;
}
.label-off {
    opacity: 1; /* Default Block */
    margin-right: -30px;
}

input:checked + .slider-clean {
    background-color: #28a745; /* Unblock color */
}

input:checked + .slider-clean:before {
    transform: translateX(60px); /* Move button */
}

input:checked + .slider-clean .label-on {
    opacity: 1;
}

input:checked + .slider-clean .label-off {
    opacity: 0;
}
</style>
