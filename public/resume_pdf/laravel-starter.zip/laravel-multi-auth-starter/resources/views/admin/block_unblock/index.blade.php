@extends('layouts.main')
@section('content')
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-12 mb-2 mt-1">
                    <div class="breadcrumbs-top">
                        <h5 class="content-header-title float-left pr-1 mb-0">Users</h5>
                        <div class="breadcrumb-wrapper d-none d-sm-block">
                            <ol class="breadcrumb p-0 mb-0 pl-1">
                                <li class="breadcrumb-item"><a href="{{route('admin.dashboard')}}"><i class="bx bx-home-alt"></i></a>
                                </li>
                                <li class="breadcrumb-item active">User
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content-body">
                <section id="basic-datatable">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body card-dashboard">
                                    <div class="table-responsive">
                                        <table id="table zero-configuration table-extended-chechbox" class="table zero-configuration">
                                            <thead>
                                                <tr>
                                                    <th>Email</th>
                                                    <th>Phone Number</th>
                                                    <th>status</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach($userArray as $key => $value)
                                                     <tr>
                                                        <td>{{$value->email}}</td>
                                                        <td>{{$value->phone_number}}</td>
                                                        <td>{{$value->status}}</td>
                                                        <td>
                                                            <label class="switch-clean">
                                                                <input type="checkbox" class="toggle-block" data-id="{{ $value->id }}" {{ !$value->is_blocked ? 'checked' : '' }}>
                                                                <span class="slider-clean">
                                                                    <span class="label-on">Unblock</span>
                                                                    <span class="label-off">Block</span>
                                                                </span>
                                                            </label>
                                                        </td>
                                                     </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>

@include('partials.toastr.toastr_css')
@include('admin/block_unblock/block_unblock_css')
@endsection

@push('scripts')
<script src="{{ asset('commonJS/blockUnblockJs.js') }}"></script>
<script>
    initializeBlockUnblockAction(
        '.toggle-block', 
        '{{ route("admin.block_unblock.user_block_unblock") }}',
        '{{ csrf_token() }}'
    );
</script>
@endpush