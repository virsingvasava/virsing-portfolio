function initializeBlockUnblockAction(selector, ajaxUrl, csrfToken) {
    $(document).ready(function () {
        $(selector).change(function () {  
            var userId = $(this).data('id');
            var isBlocked = $(this).is(':checked') ? 0 : 1; 
            $.ajax({
                url: ajaxUrl,
                type: 'POST',
                data: {
                    _token: csrfToken,   
                    user_id: userId,
                    is_blocked: isBlocked
                },
                success: function (response) {
                    toastr.options = {
                        "closeButton": true,
                        "progressBar": false,
                        "positionClass": "custom-toast-position",
                        "timeOut": "5000",
                    };
                    if(response.data == 1) {
                        toastr.error(response.message);
                    } else {
                        toastr.info(response.message);
                    }
                },
                error: function (xhr) {
                    toastr.options = {
                        "closeButton": true,
                        "progressBar": false,
                        "positionClass": "custom-toast-position",
                        "timeOut": "5000",
                    };
                    toastr.error('Something went wrong.');
                }
            });
        });
    });
}
