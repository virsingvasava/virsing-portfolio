<?php

namespace App\Repositories;

use App\Repositories\Contracts\UserRepositoryInterface;
use Illuminate\Support\Facades\File;
use App\Models\User;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Mail;
use App\Mail\UserActivationMail;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use App\Helpers\ToastrHelper;

class UserRepository implements UserRepositoryInterface
{

    public function __construct(User $model)
    {
        $this->model = $model;
    }

    public function getAll()
    {
        return $this->model->where('email', '!=', 'admin@gmail.com')->get();
    }

    public function getById($id)
    {
        return $this->model->findOrFail($id);
    }

    public function create(array $data): User
    {
        if (isset($data['profile_picture'])) {
            $data['profile_picture'] = $this->uploadImage($data['profile_picture']);
        }
        $user = $this->model->create($data);

        $this->activationLinkGenerate($user);

        return $user;
    }
    
    public function update($id, array $data): bool
    {
        $user = $this->getById($id);
        if (isset($data['profile_picture'])) {
            if ($user->profile_picture && File::exists(public_path($user->profile_picture))) {
                File::delete(public_path($user->profile_picture));
            }
            $data['profile_picture'] = $this->uploadImage($data['profile_picture']);
        }
        unset($data['password']);
        return $user->update($data);
    }

    public function delete($id): bool
    {
        try {
            $user = $this->getById($id);
    
            if ($user->profile_picture && File::exists(public_path($user->profile_picture))) {
                File::delete(public_path($user->profile_picture));
            }
    
            return $user->delete();
            
        } catch (\Exception $e) {
            \Log::error('Failed to delete user:', [
                'error' => $e->getMessage(),
                'user_id' => $id,
            ]);
    
            return false;
        }
    }
        
    private function uploadImage01($image): string
    {
        $directory = public_path('profilePicture');
        if (!File::exists($directory)) {
            File::makeDirectory($directory, 0755, true);
        }
        $fileName = time() . '_' . uniqid() . '.' . $image->getClientOriginalExtension();

        $image->move($directory, $fileName);
        return 'profilePicture/' . $fileName;
    }

    private function uploadImage($image): string
    {
        $directory = public_path('profilePicture');
        if (!File::exists($directory)) {
            File::makeDirectory($directory, 0777, true);
        }
        if ($image instanceof \Illuminate\Http\UploadedFile) {
            $fileName = time() . '_' . uniqid() . '.' . $image->getClientOriginalExtension();
            $image->move($directory, $fileName);
            return 'profilePicture/' . $fileName;
        }
        return 'error';
    }

    public function count()
    {
        return $this->model->count();
    }

    public function countWhere($column, $value)
    {
        return $this->model->where($column, $value)->count();
    }
    
    public function updateBlockStatus($userId, $isBlocked)
    {
        $user = $this->model->findOrFail($userId);
        $user->is_blocked = $isBlocked;
        $user->status = $isBlocked == 1 ? 'inactive' : 'active';
        $user->save();
        return $user;
    }

    public function activationLinkGenerate($user)
    {
        $activationToken = Str::random(60);
        $user->update([
            'activation_token' => $activationToken,
        ]);
        $activationLink = route('user.activate', ['token' => $activationToken]);
        Mail::to($user->email)->send(new UserActivationMail($user, $activationLink));
        
    }

    public function activateAccount($token)
    {
        $user = $this->model->where('activation_token', $token)->first();
        if (!$user) {
            throw new ModelNotFoundException('Invalid activation token.');
        }
        $user->status = 'active';
        $user->activation_token = null;
        $user->save();
        return $user;
    }

    public function findByEmail($email)
    {
        return User::where('email', $email)->first();
    }

}