<?php

namespace App\Repositories\Contracts;

interface EmployeeRepositoryInterface
{
    public function count();
    public function countWhere($column, $value);
}