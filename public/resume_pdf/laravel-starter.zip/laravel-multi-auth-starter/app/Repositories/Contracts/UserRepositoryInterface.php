<?php

namespace App\Repositories\Contracts;
use App\Models\User;

interface UserRepositoryInterface
{
    public function getAll();
    public function getById($id);
    public function create(array $data): User;
    public function update($id, array $data): bool;
    public function delete($id): bool;
    public function count();
    public function countWhere($column, $value);
    public function updateBlockStatus($userId, $isBlocked);
    public function activateAccount($token);
    public function findByEmail($email); 
}