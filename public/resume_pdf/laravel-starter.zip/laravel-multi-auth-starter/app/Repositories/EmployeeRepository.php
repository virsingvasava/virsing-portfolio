<?php

namespace App\Repositories;

use App\Repositories\Contracts\EmployeeRepositoryInterface;
use App\Models\Employee;

class EmployeeRepository implements EmployeeRepositoryInterface
{
    public function __construct(Employee $model)
    {
        $this->model = $model;
    }

    public function count()
    {
        return $this->model->count();
    }

    public function countWhere($column, $value)
    {
        return $this->model->where($column, $value)->count();
    }
}
