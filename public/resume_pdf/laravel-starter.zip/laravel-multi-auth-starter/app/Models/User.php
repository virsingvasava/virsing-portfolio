<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use App\Enums\UserType;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $fillable = [
        'name',
        'first_name',
        'last_name',
        'username',
        'email',
        'profile_picture',
        'phone_number',
        'status',
        'slug',
        'password',
        'user_type',
        'is_blocked',
        'activation_token',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'user_type' => \App\Enums\UserType::class,
    ];

    public function isAdmin()
    {
        return $this->user_type === 'admin';
    }

    public function isUser()
    {
        return $this->user_type === 'user';
    }

    public function isEmployee()
    {
        return $this->user_type === 'employee';
    }

    public function admin()
    {
        return $this->hasOne(Admin::class, 'user_id');  // Assuming 'user_id' in the admin table
    }

    public function employee()
    {
        return $this->hasOne(Employee::class, 'user_id');  // Assuming 'user_id' in the employee table
    }
    

}
