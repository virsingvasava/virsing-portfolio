<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;


class Employee extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $guard = 'employees';

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'user_id',
        'email',
        'phone_number',
        'password',
        'email_verified_at',
        'remember_token'
    ];
    
    protected $hidden = ['password', 'remember_token'];

   
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

}
