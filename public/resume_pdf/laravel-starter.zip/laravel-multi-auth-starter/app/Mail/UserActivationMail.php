<?php

namespace App\Mail;

use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class UserActivationMail extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    /**
     * The user instance.
     *
     * @var \App\Models\User
     */
    public User $user;

    /**
     * The activation link.
     *
     * @var string
     */
    public string $activationLink;

    /**
     * Create a new message instance.
     *
     * @param  \App\Models\User  $user
     * @param  string  $activationLink
     * @return void
     */
    public function __construct(User $user, string $activationLink)
    {
        $this->user = $user;
        $this->activationLink = $activationLink;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $data = [
            'first_name'=> $this->user->first_name,
            'last_name'=> $this->user->last_name,
            'email'=> $this->user->email,
            'phone_number' => $this->user->phone_number,
            'activation_link' => $this->activationLink,
        ];
    
        return $this->view('emails.user_activation')
                    ->subject('Account Activation')
                    ->with($data);
    }
    
}
