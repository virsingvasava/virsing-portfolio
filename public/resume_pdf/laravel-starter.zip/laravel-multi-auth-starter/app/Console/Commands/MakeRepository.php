<?php

namespace App\Console\Commands;

use Illuminate\Console\Attributes\Description;
use Illuminate\Console\Attributes\Signature;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;

#[Signature('app:make-repository')]
#[Description('Command description')]

class MakeRepository extends Command
{
    protected $signature = 'make:repository {name}';
    protected $description = 'Create a repository class and interface';

    public function handle()
    {
        $name = Str::studly($this->argument('name'));

        $repositoryPath = app_path("Repositories/{$name}Repository.php");
        $interfacePath = app_path("Repositories/Contracts/{$name}RepositoryInterface.php");

        // Create directories if they don't exist
        if (!File::exists(app_path('Repositories'))) {
            File::makeDirectory(app_path('Repositories'), 0755, true);
        }

        if (!File::exists(app_path('Repositories/Contracts'))) {
            File::makeDirectory(app_path('Repositories/Contracts'), 0755, true);
        }

        // Create Repository class
        if (!File::exists($repositoryPath)) {
            File::put($repositoryPath, $this->getRepositoryContent($name));
            $this->info("Created: {$repositoryPath}");
        } else {
            $this->error("Repository already exists!");
        }

        // Create Interface
        if (!File::exists($interfacePath)) {
            File::put($interfacePath, $this->getInterfaceContent($name));
            $this->info("Created: {$interfacePath}");
        } else {
            $this->error("Interface already exists!");
        }
    }

    protected function getRepositoryContent($name)
    {
        return <<<PHP
            <?php

            namespace App\Repositories;

            use App\Repositories\Contracts\\{$name}RepositoryInterface;

            class {$name}Repository implements {$name}RepositoryInterface
            {
                //
            }

            PHP;
    }

    protected function getInterfaceContent($name)
    {
        return <<<PHP
            <?php

            namespace App\Repositories\Contracts;

            interface {$name}RepositoryInterface
            {
                //
            }
            PHP;
    }
}