<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UserRegisterRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; 
    }

    public function rules(): array
    {
        return [
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'username' => 'nullable|string|unique:users,username|max:255', 
            'email' => 'required|email|unique:users,email|max:255',
            'profile_picture' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'phone_number' => 'required|string|unique:users,phone_number|max:15',
            'user_type' => 'required|string|max:255',
            'status' => 'nullable|string|max:255',
            'slug' => 'nullable|string|max:255',
            'password' => 'required|string|min:6|confirmed',
        ];
    }

    public function attributes(): array
    {
        return [
            'first_name' => 'first name',
            'last_name' => 'last name',
            'username' => 'username',
            'email' => 'email address',
            'profile_picture' => 'profile picture',
            'profile_picture.image' => 'Please upload a valid image.',
            'profile_picture.mimes' => 'Only jpeg, png, jpg, and gif images are allowed.',
            'profile_picture.max' => 'The profile picture should not be larger than 2MB.',
            'phone_number' => 'phone number',
            'status' => 'status',
            'user_type' => 'Select User Type',
            'slug' => 'slug',
            'password' => 'password',
            'password_confirmation' => 'confirm password',
        ];
    }
}
