<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UserLoginRequest extends FormRequest
{
    public function authorize()
    {
        return true; // allow this request
    }

    public function rules()
    {
        return [
            'email' => ['required', 'email', 'max:255'],
            'password' => ['required', 'string', 'min:6'],
        ];
    }

    public function messages()
    {
        return [
            'email.required' => 'Email field is required.',
            'email.email' => 'Please provide a valid email address.',
            'password.required' => 'Password field is required.',
            'password.min' => 'Password must be at least 6 characters.',
        ];
    }
}
