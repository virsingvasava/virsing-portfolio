<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repositories\Contracts\UserRepositoryInterface;
use App\Http\Requests\UserBlockUnblockRequest;
use App\Helpers\ToastrHelper;

class UserBlockUnblockController extends Controller
{
    protected $userRepository;

    public function __construct(UserRepositoryInterface $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    public function index(Request $request)
    {
        $userArray = $this->userRepository->getAll();
        return view('admin.block_unblock.index', compact('userArray'));
    }
    
    public function user_block_unblock(UserBlockUnblockRequest $request)
    {
        $user = $this->userRepository->updateBlockStatus($request->user_id, $request->is_blocked);
        return response()->json([
            'data' => $user->is_blocked,  
            'success' => true,  
            'message' => $user->is_blocked ? 'User blocked successfully!' : 'User unblocked successfully!',
        ]);
    }
}


