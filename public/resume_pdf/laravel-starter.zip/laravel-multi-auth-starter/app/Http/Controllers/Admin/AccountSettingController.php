<?php

namespace App\Http\Controllers\Admin;

use App\Repositories\Contracts\AccountSettingRepositoryInterface;
use App\Http\Controllers\Controller;
use App\Http\Requests\UpdateAccountSettingRequest;
use App\Http\Requests\ChangePasswordRequest;
use Illuminate\Http\Request;
Use App\Models\User;
Use Auth;
use App\Helpers\ToastrHelper;

class AccountSettingController extends Controller
{
    protected $accountSettingRepository;

    public function __construct(AccountSettingRepositoryInterface $accountSettingRepository)
    {
        $this->accountSettingRepository = $accountSettingRepository;
    }

    public function profile()
    {
        $admin = $this->accountSettingRepository->getAdminUserInfo(Auth::user()->user_id);
        if ($admin && $admin->user) {
            $user = $admin->user;
        } else {
            $user = null;
        }
        if (!$admin) {
            return redirect()->route('admin.dashboard')->with('error', 'User not found.');
        }
        return view('admin.settings.profile', compact('user'));
    }

    public function update($id, UpdateAccountSettingRequest $request)
    {
        $this->accountSettingRepository->update($id, $request->validated());
        ToastrHelper::flash('info', 'Profile updated successfully !');
        return redirect()->route('admin.dashboard');
    }

    public function changePasswordForm()
    {
        $user = $this->accountSettingRepository->getAuthUserInfo();
        if (!$user) {
            ToastrHelper::flash('error', 'User not found !');
            return redirect()->route('admin.dashboard');
        }
        return view('admin.settings.changePassword', compact('user'));
    }

    public function changePassword($id, ChangePasswordRequest $request)
    {        
        $result = $this->accountSettingRepository->changePassword($id, $request->current_password, $request->password);
        if (isset($result['error'])) {
            return redirect()->back()->withErrors(['current_password' => $result['error']]);
        }
        ToastrHelper::flash('info', 'Change Password successfully !');
        return redirect()->route('admin.dashboard');
    }

    public function logout(Request $request)
    {
        $this->accountSettingRepository->logout();
        ToastrHelper::flash('info', 'You have been logged out successfully !');
        return redirect()->route('admin.login');
    }
    

}
