<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Repositories\Contracts\EmployeeRepositoryInterface;
use App\Repositories\Contracts\CategoryRepositoryInterface;
use App\Repositories\Contracts\ProductRepositoryInterface;
use App\Repositories\Contracts\UserRepositoryInterface;
use App\Helpers\ToastrHelper;

class DashboardController extends Controller
{
    protected $employeeRepository;
    protected $categoryRepository;
    protected $productRepository;
    protected $userRepository;

    public function __construct(
        EmployeeRepositoryInterface $employeeRepository,
        CategoryRepositoryInterface $categoryRepository,
        ProductRepositoryInterface $productRepository,
        UserRepositoryInterface $userRepository,
    ) {
        $this->employeeRepository = $employeeRepository;
        $this->categoryRepository = $categoryRepository;
        $this->productRepository = $productRepository;
        $this->userRepository = $userRepository;

    }
    
    public function index()
    {
        $totalUsers = $this->userRepository->count();
        $totalEmployee = $this->employeeRepository->count();

        $categoriesCount = $this->categoryRepository->count();
        $productsCount = $this->productRepository->count();
    
        return view('admin.dashboard', compact(
            'totalUsers',
            'totalEmployee',
            'categoriesCount',
            'productsCount'
        ));
    }
}