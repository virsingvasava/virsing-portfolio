<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Repositories\Contracts\ProfileRepositoryInterface;
use App\Http\Requests\UpdateAccountSettingRequest;
use App\Http\Requests\ChangePasswordRequest;
use Illuminate\Http\Request;
use App\Helpers\ToastrHelper;
Use App\Models\User;
Use Auth;

class ProfileController extends Controller
{
    protected $profileRepository;

    public function __construct(ProfileRepositoryInterface $profileRepository)
    {
        $this->profileRepository = $profileRepository;
    }

    public function profile()
    {
        $user = $this->profileRepository->getAuthUserInfo();
        if (!$user) {
            return redirect()->route('admin.dashboard')->with('error', 'User not found.');
        }
        return view('admin.settings.profile', compact('user'));
    }

    public function update($id, UpdateAccountSettingRequest $request)
    {
        $this->profileRepository->update($id, $request->validated());
        ToastrHelper::flash('info', 'Profile updated successfully !');
        return redirect()->route('admin.dashboard');
    }

    public function changePasswordForm()
    {
        $user = $this->profileRepository->getAuthUserInfo();
        if (!$user) {
            ToastrHelper::flash('error', 'User not found !');
            return redirect()->route('admin.dashboard');
        }
        return view('admin.settings.changePassword', compact('user'));
    }

    public function changePassword($id, ChangePasswordRequest $request)
    {        
        $result = $this->profileRepository->changePassword($id, $request->current_password, $request->password);
        if (isset($result['error'])) {
            return redirect()->back()->withErrors(['current_password' => $result['error']]);
        }
        return redirect()->route('admin.dashboard')->with('success', $result['success']);
    }

    public function logout(Request $request)
    {
        $this->profileRepository->logout();
        ToastrHelper::flash('info', 'You have been logged out successfully !');
        return redirect()->route('login');
    }
    
}