<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Helpers\ToastrHelper;

class AuthController extends Controller
{
    public function adminLoginForm(Request $request)
    {
        return view('admin.auth.login');
    }
    public function login(Request $request)
    {
        session(['guard' => 'admin']);
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:6',
        ]);
        $credentials = $request->only('email', 'password');
        if (Auth::guard('admin')->attempt($credentials, $request->remember)) {
            ToastrHelper::flash('info', 'Welcome back, Admin!');
            return redirect()->route('admin.dashboard');
        }
        ToastrHelper::flash('error', 'Invalid email or password !');
        return back();
    }

    public function logout()
    {
        Auth::guard('admin')->logout();
        ToastrHelper::flash('info', 'Logged out successfully !');
        return redirect()->route('admin.login');
    }
}
