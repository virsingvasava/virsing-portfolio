<?php

namespace App\Http\Controllers\Admin;

use App\Repositories\Contracts\UserRepositoryInterface;
use App\Http\Requests\StoreUserRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Helpers\ToastrHelper;

class UserController extends Controller
{
    protected $userRepository;

    public function __construct(UserRepositoryInterface $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    public function index(Request $request)
    {
        $userArray = $this->userRepository->getAll();
        return view('admin.users.index', compact('userArray'));
    }

    public function create()
    {
        return view('admin.users.create');
    }

    public function store(StoreUserRequest $request)
    {
        $data = $request->all();
        if ($request->hasFile('profile_picture')) {
            $data['profile_picture'] = $request->file('profile_picture');
        }
        $this->userRepository->create($data);
        ToastrHelper::flash('info', 'User created successfully.');
        return redirect()->route('admin.user.index');
    }

    public function update($id, UpdateUserRequest $request)
    {
        $data = $request->all();
        if ($request->hasFile('profile_picture')) {
            $data['profile_picture'] = $request->file('profile_picture');
        }
        $this->userRepository->update($id, $data);
        ToastrHelper::flash('info', 'User updated successfully!');
        return redirect()->route('admin.user.index');
    }

    public function edit(Request $request, $id)
    {
        $user = $this->userRepository->getById($id);
        if (!$user) {
            ToastrHelper::flash('error', 'User not found!');
            return redirect()->route('admin.user.index');
        }
        return view('admin.users.edit', compact('user'));
    }

    public function view(Request $request, $id)
    {
        $user = $this->userRepository->getById($id);
        if (!$user) {
            ToastrHelper::flash('error', 'User not found!');
            return redirect()->route('admin.user.index');
        }
        return view('admin.users.view', compact('user'));
    }

    public function destroy(Request $request)
    {
        $isDeleted = $this->userRepository->delete($request->id);
        return response()->json([
            'success' => $isDeleted,
            'message' => $isDeleted ? 'Item deleted successfully!' : 'Item not found or could not be deleted.',
        ], $isDeleted ? 200 : 404);
    }

}