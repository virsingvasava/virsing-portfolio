<?php

namespace App\Http\Controllers\Employee;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repositories\Contracts\ProductRepositoryInterface;
use App\Http\Requests\Product\StoreProductRequest;
use App\Http\Requests\Product\UpdateProductRequest;
use App\Helpers\ToastrHelper;

class ProductController extends Controller
{
    protected $productRepository;

    public function __construct(ProductRepositoryInterface $productRepository)
    {
        $this->productRepository = $productRepository;
    }
    
    public function index(Request $request)
    {
        $productArray = $this->productRepository->getAll();
        return view('employees.products.index', compact('productArray'));
    }

    public function create()
    {
        return view('employees.products.create');
    }

    public function store(StoreProductRequest $request)
    {
        $this->productRepository->create($request->validated());
        ToastrHelper::flash('info', 'Product created successfully !');
        return redirect()->route('employee.product.index');
    }

    public function update($id, UpdateProductRequest $request)
    {
        $this->productRepository->update($id, $request->validated());
        ToastrHelper::flash('info', 'Product updated successfully !');
        return redirect()->route('employee.product.index');
    }

    public function edit(Request $request, $id)
    {
        $product = $this->productRepository->getById($id);
        if (!$product) {
            ToastrHelper::flash('error', 'Product not found !');
            return redirect()->route('employee.product.index');
        }
        return view('employees.products.edit', compact('product'));
    }

    public function view(Request $request, $id)
    {
        $product = $this->productRepository->getById($id);
        if (!$product) {
            ToastrHelper::flash('error', 'Product not found !');
            return redirect()->route('user.product.index');
        }
        return view('employees.products.view', compact('product'));
    }

    
    public function destroy(Request $request)
    {
        $isDeleted = $this->productRepository->delete($request->id);
        return response()->json([
            'success' => $isDeleted,
            'message' => $isDeleted ? 'Item deleted successfully!' : 'Item not found or could not be deleted.',
        ], $isDeleted ? 200 : 404);
    }

}
