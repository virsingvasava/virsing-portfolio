<?php

namespace App\Http\Controllers\Employee;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Repositories\Contracts\CategoryRepositoryInterface;
use App\Http\Requests\Category\StoreCategoryRequest;
use App\Http\Requests\Category\UpdateCategoryRequest;
use App\Helpers\ToastrHelper;

class CategoryController extends Controller
{
    protected $categoryRepository;

    public function __construct(CategoryRepositoryInterface $categoryRepository)
    {
        $this->categoryRepository = $categoryRepository;
    }

    public function index(Request $request)
    {
        $categoryArray = $this->categoryRepository->getAll();
        return view('employees.categories.index', compact('categoryArray'));
    }

    public function create()
    {
        return view('employees.categories.create');
    }

    public function store(StoreCategoryRequest $request)
    {
        $this->categoryRepository->create($request->validated());
        ToastrHelper::flash('info', 'Category created successfully.');
        return redirect()->route('employee.category.index');
    }

    public function update($id, UpdateCategoryRequest $request)
    {
        $this->categoryRepository->update($id, $request->validated());
        ToastrHelper::flash('info', 'Category updated successfully.');
        return redirect()->route('employee.category.index');
    }

    public function edit(Request $request, $id)
    {
        $category = $this->categoryRepository->getById($id);
        if (!$category) {
            ToastrHelper::flash('error', 'Category not found !');
            return redirect()->route('employee.category.index');
        }
        return view('employees.categories.edit', compact('category'));
    }

    public function view(Request $request, $id)
    {
        $category = $this->categoryRepository->getById($id);
        if (!$category) {
            ToastrHelper::flash('error', 'Category not found !');
            return redirect()->route('employee.category.index');
        }
        return view('employees.categories.view', compact('category'));
    }

    public function destroy(Request $request)
    {
        $isDeleted = $this->categoryRepository->delete($request->id);
        return response()->json([
            'success' => $isDeleted,
            'message' => $isDeleted ? 'Item deleted successfully!' : 'Item not found or could not be deleted.',
        ], $isDeleted ? 200 : 404);
    }
}
