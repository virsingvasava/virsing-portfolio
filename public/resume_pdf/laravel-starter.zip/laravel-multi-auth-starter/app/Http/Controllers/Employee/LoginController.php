<?php

namespace App\Http\Controllers\Employee;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Helpers\ToastrHelper;

class LoginController extends Controller
{
    public function showLoginForm()
    {
        return view('employees.auth.login');
    }

    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:6',
        ]);
        $credentials = $request->only('email', 'password');
        if (Auth::guard('employee')->attempt($credentials, $request->remember)) {
            ToastrHelper::flash('info', 'Welcome back, Employee!');
            return redirect()->route('employee.dashboard');
        }
        ToastrHelper::flash('error', 'Invalid email or password!');
        return back();
    }

    public function logout()
    {
        Auth::guard('employee')->logout();
        ToastrHelper::flash('info', 'Logged out successfully.!');
        return redirect()->route('employee.login');
    }
}
