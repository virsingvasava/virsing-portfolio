<?php

namespace App\Http\Controllers\Employee;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Repositories\Contracts\EmployeeRepositoryInterface;
use App\Repositories\Contracts\CategoryRepositoryInterface;
use App\Repositories\Contracts\ProductRepositoryInterface;
use App\Helpers\ToastrHelper;

class DashboardController extends Controller
{
    protected $employeeRepository;
    protected $categoryRepository;
    protected $productRepository;

    public function __construct(
        EmployeeRepositoryInterface $employeeRepository,
        CategoryRepositoryInterface $categoryRepository,
        ProductRepositoryInterface $productRepository
    ) {
        $this->employeeRepository = $employeeRepository;
        $this->categoryRepository = $categoryRepository;
        $this->productRepository = $productRepository;
    }
    
    public function index()
    {
        $totalEmployee = $this->employeeRepository->count();
        $activeEmployee = $this->employeeRepository->countWhere('status', 'active');

        $categoriesCount = $this->categoryRepository->count();
        $productsCount = $this->productRepository->count();
    
        return view('employees.dashboard.index', compact(
            'totalEmployee',
            'activeEmployee',
            'categoriesCount',
            'productsCount'
        ));
    }
}
