<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Repositories\Contracts\UserRepositoryInterface;
use App\Repositories\Contracts\CategoryRepositoryInterface;
use App\Repositories\Contracts\ProductRepositoryInterface;
use App\Helpers\ToastrHelper;

class DashboardController extends Controller
{
    protected $userRepository;
    protected $categoryRepository;
    protected $productRepository;

    public function __construct(
        UserRepositoryInterface $userRepository,
        CategoryRepositoryInterface $categoryRepository,
        ProductRepositoryInterface $productRepository
    ) {
        $this->userRepository = $userRepository;
        $this->categoryRepository = $categoryRepository;
        $this->productRepository = $productRepository;
    }

    public function index()
    {
        $totalUsers = $this->userRepository->count();
        $activeUsers = $this->userRepository->countWhere('status', 'active');
        $inactiveUsers = $this->userRepository->countWhere('status', 'inactive');
        $categoriesCount = $this->categoryRepository->count();
        $productsCount = $this->productRepository->count();

        return view('users.dashboard.index', compact(
            'totalUsers',
            'activeUsers',
            'inactiveUsers',
            'categoriesCount',
            'productsCount'
        ));
    }
    
}
