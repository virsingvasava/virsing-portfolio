<?php
namespace App\Http\Controllers\User;

use App\Http\Requests\UserRegisterRequest;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\UserLoginRequest;
use App\Repositories\Contracts\UserRepositoryInterface;
use App\Helpers\ToastrHelper;

class LoginController extends Controller
{
    protected $userRepository;

    public function __construct(UserRepositoryInterface $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    public function showLoginForm()
    {
        return view('users.auth.login');
    }

    public function login(UserLoginRequest $request)
    {
        $credentials = $request->only('email', 'password');

        $user = $this->userRepository->findByEmail($credentials['email']);

        if (!$user) {
            ToastrHelper::flash('error', 'We could not find an account with that email.');
            return back();
        }

        if (!\Illuminate\Support\Facades\Hash::check($credentials['password'], $user->password)) {
            ToastrHelper::flash('error', 'The provided password is incorrect.');
            return back();
        }
        Auth::guard('user')->login($user, $request->filled('remember'));
        ToastrHelper::flash('info', 'Welcome back, User Panel !');
        return redirect()->route('user.dashboard');
    }

    public function logout()
    {
        Auth::guard('user')->logout();
        ToastrHelper::flash('info', 'Logged out successfully !');
        return redirect()->route('user.login');
    }

    public function showRegisterForm()
    {
        return view('users.auth.register');
    }

    public function registerUsers(UserRegisterRequest $request)
    {
        $data = $request->all();
        if ($request->hasFile('profile_picture')) {
            $data['profile_picture'] = $request->file('profile_picture')->store('profiles', 'public');
        }
        $this->userRepository->create($data);
        ToastrHelper::flash('info', 'Welcome to the User Panel!');
        return redirect()->route('user.dashboard');
    }

    public function activate($token)
    {
        $user = $this->userRepository->activateAccount($token);
        if (!$user) {
            ToastrHelper::flash('error', 'Invalid activation token !');
            return redirect()->route('user.login');
        }
        ToastrHelper::flash('info', 'Your account has been activated successfully !');
        return redirect()->route('user.login');
    }
}
